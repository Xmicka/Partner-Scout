/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { COUNTRIES, flag } from "../countries.js";
import { Globe, X } from "lucide-react";

interface CountrySelectorProps {
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  id?: string;
}

export function CountrySelector({ value, onChange, placeholder = "Search country...", id = "country-autocomplete" }: CountrySelectorProps) {
  const [query, setQuery] = useState(value);
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync state with parent value
  useEffect(() => {
    setQuery(value);
  }, [value]);

  // Filter countries list
  const matches = COUNTRIES.filter(([name]) =>
    name.toLowerCase().includes(query.toLowerCase().trim())
  ).slice(0, 12);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSelect = (name: string) => {
    onChange(name);
    setQuery(name);
    setIsOpen(false);
    setHighlightedIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen) {
      if (e.key === "ArrowDown") {
        setIsOpen(true);
      }
      return;
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setHighlightedIndex(prev => Math.min(prev + 1, matches.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setHighlightedIndex(prev => Math.max(prev - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (highlightedIndex >= 0 && matches[highlightedIndex]) {
        handleSelect(matches[highlightedIndex][0]);
      } else if (matches.length > 0) {
        handleSelect(matches[0][0]);
      }
    } else if (e.key === "Escape") {
      setIsOpen(false);
    }
  };

  return (
    <div className="relative w-full text-slate-800 dark:text-slate-200" ref={dropdownRef} id={`${id}-wrapper`}>
      <div className="relative flex items-center">
        <Globe className="absolute left-3 w-4 h-4 text-neutral-400 dark:text-neutral-500" />
        <input
          ref={inputRef}
          type="text"
          id={id}
          value={query}
          onFocus={() => setIsOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
            setHighlightedIndex(-1);
          }}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full pl-9 pr-8 h-11 bg-[#FDFBF7] dark:bg-[#252523] border border-[#EAE5DB] dark:border-[#444440] rounded-lg text-sm text-[#1A1A1B] dark:text-[#E8E6E0] focus:outline-none focus:ring-1 focus:ring-[#EF6C00] transition-colors"
          autoComplete="off"
        />
        {query && (
          <button
            type="button"
            onClick={() => {
              setQuery("");
              onChange("");
              setIsOpen(true);
              inputRef.current?.focus();
            }}
            className="absolute right-3 p-0.5 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-300"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {isOpen && matches.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white dark:bg-[#1e1e1c] border border-[#EBE4D8] dark:border-[#333330] rounded-lg max-h-60 overflow-y-auto z-50 shadow-lg divide-y divide-neutral-100 dark:divide-neutral-800">
          {matches.map(([name, fl], idx) => (
            <div
              key={name}
              onMouseDown={() => handleSelect(name)}
              onMouseEnter={() => setHighlightedIndex(idx)}
              className={`flex items-center gap-2.5 px-3 py-2 text-xs cursor-pointer select-none transition-colors ${
                highlightedIndex === idx
                  ? "bg-[#EF6C00]/10 text-[#EF6C00]"
                  : "text-[#514F4A] dark:text-[#a8a69e] hover:bg-neutral-50 dark:hover:bg-neutral-850"
              }`}
            >
              <span className="text-base select-none">{fl}</span>
              <span className="font-medium">{name}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { TrendingUp, Award, Activity, Globe, LayoutGrid, Users } from "lucide-react";
import { Campaign, PartnerLead } from "../types.js";
import { flag } from "../countries.js";

interface AnalyticsViewProps {
  campaigns: Campaign[];
}

export function AnalyticsView({ campaigns }: AnalyticsViewProps) {
  // Aggregate all leads across campaigns
  const allLeads = campaigns.flatMap(camp => {
    return (camp.leads || []).map(lead => ({
      ...lead,
      country: camp.country
    }));
  });

  if (allLeads.length === 0) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-16 text-center text-xs text-slate-400 font-light font-sans shadow-2xs" id="analytics-empty">
        <TrendingUp className="w-10 h-10 mx-auto text-neutral-300 mb-3 animate-pulse" />
        <h3>No analytics data compiled yet</h3>
        <p className="mt-1">Scout country markets and acquire leads to generate strategic dashboard charts.</p>
      </div>
    );
  }

  // Calculate high-level stats
  const totalLeads = allLeads.length;
  const uniqueCountries = Array.from(new Set(allLeads.map(l => l.country))).filter(Boolean);
  
  // Average fit score
  let totalFit = 0;
  let countWithFit = 0;
  allLeads.forEach(l => {
    // Check both standard score and fit_score property
    const scoreVal = (l as any).fit_score !== undefined ? (l as any).fit_score : ((l as any).fitScore || 70);
    if (scoreVal !== undefined) {
      totalFit += Number(scoreVal);
      countWithFit++;
    }
  });
  const avgFit = countWithFit > 0 ? Math.round(totalFit / countWithFit) : 70;

  // Conversion rate (signed / total)
  const signedLeads = allLeads.filter(l => {
    const status = (l as any).outreachStatus || (l as any).outreach_status || "";
    return ["partnered", "signed"].includes(status.toLowerCase());
  }).length;
  const convRate = totalLeads > 0 ? Math.round((signedLeads / totalLeads) * 100) : 0;

  // 1. Outreach stages funnel data
  const stagesCount: Record<string, number> = {
    new: 0,
    contacted: 0,
    in_progress: 0,
    signed: 0
  };

  allLeads.forEach(l => {
    const status = ((l as any).outreachStatus || (l as any).outreach_status || "new").toLowerCase();
    if (["new", "not_contacted"].includes(status)) {
      stagesCount.new++;
    } else if (["contact_made", "contacted"].includes(status)) {
      stagesCount.contacted++;
    } else if (["pitch_sent", "meeting_scheduled", "in_progress"].includes(status)) {
      stagesCount.in_progress++;
    } else if (["partnered", "signed"].includes(status)) {
      stagesCount.signed++;
    }
  });

  const funnelData = [
    { label: "Cataloged Leads (New)", count: stagesCount.new, color: "bg-purple-600" },
    { label: "Contact Initiated", count: stagesCount.contacted, color: "bg-blue-600" },
    { label: "Active Vetting (Pitch/Meeting)", count: stagesCount.in_progress, color: "bg-amber-500" },
    { label: "OrangeHRM Partnered!", count: stagesCount.signed, color: "bg-emerald-600" }
  ];
  const maxFunnel = Math.max(...funnelData.map(d => d.count), 1);

  // 2. Leads by Country
  const countryCounts: Record<string, number> = {};
  allLeads.forEach(l => {
    countryCounts[l.country] = (countryCounts[l.country] || 0) + 1;
  });
  const countryBreakdown = Object.entries(countryCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);
  const maxCountry = Math.max(...countryBreakdown.map(d => d.count), 1);

  // 3. Fit score distribution
  const fitCounts = { High: 0, Mid: 0, Low: 0 };
  allLeads.forEach(l => {
    const score = (l as any).fit_score !== undefined ? (l as any).fit_score : 70;
    if (score >= 70) fitCounts.High++;
    else if (score >= 40) fitCounts.Mid++;
    else fitCounts.Low++;
  });
  const maxFit = Math.max(...Object.values(fitCounts), 1);

  // 4. Firm size segments
  const segmentCounts = { SME: 0, "Mid-Market": 0, Enterprise: 0 };
  allLeads.forEach(l => {
    const seg = l.firmSizeSegment || "SME";
    if (seg === "Enterprise") segmentCounts.Enterprise++;
    else if (seg === "Mid-Market") segmentCounts["Mid-Market"]++;
    else segmentCounts.SME++;
  });
  const maxSeg = Math.max(...Object.values(segmentCounts), 1);

  return (
    <div className="space-y-6" id="analytics-view-root">
      
      {/* Top statistics overview block */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#FAF6F0] border border-[#EBE4D8] rounded-xl p-4 flex items-center gap-3">
          <div className="w-9 h-9 bg-[#EF6C00]/10 text-[#EF6C00] rounded-lg flex items-center justify-center font-bold">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <div className="text-[10px] text-[#827F78] uppercase font-mono tracking-wider">Scouted Network</div>
            <div className="text-xl font-serif font-bold text-[#1A1A1B]">{totalLeads} Lead{totalLeads !== 1 ? "s" : ""}</div>
          </div>
        </div>

        <div className="bg-[#FAF6F0] border border-[#EBE4D8] rounded-xl p-4 flex items-center gap-3">
          <div className="w-9 h-9 bg-emerald-50 text-emerald-800 rounded-lg flex items-center justify-center font-bold">
            <Globe className="w-4 h-4 text-emerald-600" />
          </div>
          <div>
            <div className="text-[10px] text-[#827F78] uppercase font-mono tracking-wider">Observatory Reach</div>
            <div className="text-xl font-serif font-bold text-emerald-800">{uniqueCountries.length} Region{uniqueCountries.length !== 1 ? "s" : ""}</div>
          </div>
        </div>

        <div className="bg-[#FAF6F0] border border-[#EBE4D8] rounded-xl p-4 flex items-center gap-3">
          <div className="w-9 h-9 bg-purple-50 text-purple-800 rounded-lg flex items-center justify-center font-bold">
            <Award className="w-4 h-4 text-purple-600" />
          </div>
          <div>
            <div className="text-[10px] text-[#827F78] uppercase font-mono tracking-wider">Average Target Fit</div>
            <div className="text-xl font-serif font-bold text-purple-900">{avgFit}/100</div>
          </div>
        </div>

        <div className="bg-[#FAF6F0] border border-[#EBE4D8] rounded-xl p-4 flex items-center gap-3">
          <div className="w-9 h-9 bg-amber-50 text-amber-800 rounded-lg flex items-center justify-center font-bold">
            <Activity className="w-4 h-4 text-amber-600" />
          </div>
          <div>
            <div className="text-[10px] text-[#827F78] uppercase font-mono tracking-wider">Conversion Ratio</div>
            <div className="text-xl font-serif font-bold text-amber-900">{convRate}%</div>
          </div>
        </div>
      </div>

      {/* Grid containing dashboard visual charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Chart 1: Funnel */}
        <div className="bg-white border border-[#EBE4D8] rounded-xl p-5 shadow-xs">
          <h3 className="font-serif text-sm font-bold text-[#1A1A1B] uppercase tracking-wider mb-4">
            Outreach CRM Funnel
          </h3>
          <div className="space-y-4">
            {funnelData.map((d, i) => {
              const pct = maxFunnel > 0 ? (d.count / maxFunnel) * 100 : 5;
              return (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-44 text-right text-xs text-neutral-500 font-medium truncate" title={d.label}>
                    {d.label}
                  </div>
                  <div className="flex-1 bg-[#FAF6F0] border border-[#EBE4D8]/50 h-8 rounded-lg overflow-hidden relative">
                    <div 
                      className={`h-full ${d.color} rounded-r-lg transition-all duration-500 flex items-center px-3`}
                      style={{ width: `${Math.max(8, pct)}%` }}
                    >
                      <span className="text-[10px] font-bold text-white font-mono">
                        {d.count}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 2: Leads by Country */}
        <div className="bg-white border border-[#EBE4D8] rounded-xl p-5 shadow-xs">
          <h3 className="font-serif text-sm font-bold text-[#1A1A1B] uppercase tracking-wider mb-4">
            Regional Densities
          </h3>
          <div className="space-y-4">
            {countryBreakdown.map((d, i) => {
              const pct = maxCountry > 0 ? (d.count / maxCountry) * 100 : 5;
              return (
                <div key={i} className="flex items-center gap-4">
                  <div className="w-32 text-right text-xs text-neutral-500 font-medium flex items-center justify-end gap-1.5 truncate">
                    <span>{flag(d.name)}</span>
                    <span className="truncate">{d.name}</span>
                  </div>
                  <div className="flex-1 bg-[#FAF6F0] border border-[#EBE4D8]/50 h-6 rounded-md overflow-hidden">
                    <div 
                      className="h-full bg-[#EF6C00] rounded-r-md transition-all duration-500"
                      style={{ width: `${Math.max(5, pct)}%` }}
                    />
                  </div>
                  <div className="w-8 text-xs font-mono font-bold text-[#1A1A1B]">
                    {d.count}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 3: Fit Score Distribution */}
        <div className="bg-white border border-[#EBE4D8] rounded-xl p-5 shadow-xs">
          <h3 className="font-serif text-sm font-bold text-[#1A1A1B] uppercase tracking-wider mb-4">
            Fit Score Classifications
          </h3>
          <div className="space-y-4">
            {Object.entries(fitCounts).map(([tier, count]) => {
              const pct = maxFit > 0 ? (count / maxFit) * 100 : 5;
              const color = tier === "High" ? "bg-emerald-600" : tier === "Mid" ? "bg-amber-500" : "bg-red-500";
              return (
                <div key={tier} className="flex items-center gap-4">
                  <div className="w-24 text-right text-xs text-neutral-500 font-medium">
                    {tier} Fit
                  </div>
                  <div className="flex-1 bg-[#FAF6F0] border border-[#EBE4D8]/50 h-6 rounded-md overflow-hidden">
                    <div 
                      className={`h-full ${color} rounded-r-md transition-all duration-500`}
                      style={{ width: `${Math.max(5, pct)}%` }}
                    />
                  </div>
                  <div className="w-8 text-xs font-mono font-bold text-[#1A1A1B]">
                    {count}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 4: Firm Size Distribution */}
        <div className="bg-white border border-[#EBE4D8] rounded-xl p-5 shadow-xs">
          <h3 className="font-serif text-sm font-bold text-[#1A1A1B] uppercase tracking-wider mb-4">
            Firm Sizing Distribution
          </h3>
          <div className="space-y-4">
            {Object.entries(segmentCounts).map(([seg, count]) => {
              const pct = maxSeg > 0 ? (count / maxSeg) * 100 : 5;
              const color = seg === "Enterprise" ? "bg-purple-600" : seg === "Mid-Market" ? "bg-amber-500" : "bg-blue-600";
              return (
                <div key={seg} className="flex items-center gap-4">
                  <div className="w-24 text-right text-xs text-neutral-500 font-medium">
                    {seg}
                  </div>
                  <div className="flex-1 bg-[#FAF6F0] border border-[#EBE4D8]/50 h-6 rounded-md overflow-hidden">
                    <div 
                      className={`h-full ${color} rounded-r-md transition-all duration-500`}
                      style={{ width: `${Math.max(5, pct)}%` }}
                    />
                  </div>
                  <div className="w-8 text-xs font-mono font-bold text-[#1A1A1B]">
                    {count}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}

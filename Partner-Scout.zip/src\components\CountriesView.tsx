/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Globe, ShieldCheck, Activity, Award } from "lucide-react";
import { Campaign } from "../types.js";
import { flag } from "../countries.js";

interface CountriesViewProps {
  campaigns: Campaign[];
  onSelectCountry: (countryName: string) => void;
}

export function CountriesView({ campaigns, onSelectCountry }: CountriesViewProps) {
  // Group campaigns/leads by country
  const byCountry: Record<string, {
    country: string;
    totalLeads: number;
    highFit: number;
    active: number;
    signed: number;
  }> = {};

  campaigns.forEach(camp => {
    const country = camp.country;
    if (!byCountry[country]) {
      byCountry[country] = {
        country,
        totalLeads: 0,
        highFit: 0,
        active: 0,
        signed: 0
      };
    }
    
    const leads = camp.leads || [];
    byCountry[country].totalLeads += leads.length;
    byCountry[country].highFit += leads.filter(l => l.firmSizeSegment === "Enterprise" || (l as any).fit_tier === "high" || ((l as any).fit_score && (l as any).fit_score >= 70)).length;
    byCountry[country].signed += leads.filter(l => (l as any).outreachStatus === "partnered" || (l as any).outreach_status === "signed").length;
    byCountry[country].active += leads.filter(l => 
      ["contact_made", "pitch_sent", "meeting_scheduled", "contacted", "in_progress"].includes((l as any).outreachStatus || (l as any).outreach_status)
    ).length;
  });

  const countries = Object.values(byCountry).sort((a, b) => a.country.localeCompare(b.country));

  return (
    <div className="space-y-6" id="countries-view-root">
      <div className="bg-[#FAF6F0] border border-[#EBE4D8] rounded-xl p-5 mb-4">
        <h3 className="font-serif text-lg font-bold text-[#1A1A1B] flex items-center gap-2">
          <Globe className="w-5 h-5 text-[#EF6C00]" />
          Sovereign Territories Observatory
        </h3>
        <p className="text-xs text-[#514F4A] mt-1 font-light leading-relaxed">
          Aggregated channel viability audits indexed by target country. Explore custom reseller networks, regional compliance levels, and signing percentages across scanned markets.
        </p>
      </div>

      {countries.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-16 text-center text-xs text-slate-400 font-light font-sans shadow-2xs">
          <Globe className="w-10 h-10 mx-auto text-neutral-300 mb-3 animate-pulse" />
          <h3>No countries scouted yet</h3>
          <p className="mt-1">Launch a vetting scan campaign to populate regional observational ledgers.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {countries.map((c) => (
            <div
              key={c.country}
              onClick={() => onSelectCountry(c.country)}
              className="bg-white border border-[#EBE4D8] hover:border-[#EF6C00] hover:shadow-md rounded-xl p-5 cursor-pointer transition-all duration-200 group relative flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center gap-3.5 mb-4">
                  <span className="text-3xl filter drop-shadow-sm select-none" role="img" aria-label={c.country}>
                    {flag(c.country)}
                  </span>
                  <div>
                    <h4 className="font-serif text-base font-bold text-[#1A1A1B] group-hover:text-[#EF6C00] transition-colors leading-tight">
                      {c.country}
                    </h4>
                    <span className="text-[10px] font-mono text-slate-400 font-bold uppercase tracking-wider block mt-0.5">
                      {c.totalLeads} Target Lead{c.totalLeads !== 1 ? "s" : ""}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono mt-4">
                  <div className="bg-[#FAF6F0]/50 p-2.5 rounded-lg border border-[#EBE4D8]/50">
                    <div className="text-emerald-700 font-bold text-xs">{c.highFit}</div>
                    <div className="text-neutral-400 text-[8px] tracking-wider uppercase mt-0.5 font-bold">High Fit</div>
                  </div>
                  <div className="bg-[#FAF6F0]/50 p-2.5 rounded-lg border border-[#EBE4D8]/50">
                    <div className="text-indigo-700 font-bold text-xs">{c.active}</div>
                    <div className="text-neutral-400 text-[8px] tracking-wider uppercase mt-0.5 font-bold">Active</div>
                  </div>
                  <div className="bg-[#FAF6F0]/50 p-2.5 rounded-lg border border-[#EBE4D8]/50">
                    <div className="text-[#EF6C00] font-bold text-xs">{c.signed}</div>
                    <div className="text-neutral-400 text-[8px] tracking-wider uppercase mt-0.5 font-bold">Signed</div>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-dashed border-[#EBE4D8] flex items-center justify-between text-[10px] font-semibold text-[#EF6C00] font-mono uppercase tracking-wider">
                <span>Explore Region Dossiers</span>
                <span className="group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

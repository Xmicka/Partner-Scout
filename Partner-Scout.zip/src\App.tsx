/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Search, 
  Building2, 
  Globe, 
  Users, 
  TrendingUp, 
  Coins, 
  Award, 
  ShieldCheck, 
  Sparkles, 
  Plus, 
  Trash2, 
  ExternalLink, 
  Briefcase, 
  Clock, 
  ArrowUpRight, 
  Check, 
  Loader2, 
  ChevronRight, 
  Info, 
  FileText, 
  Filter, 
  Activity, 
  ChevronLeft,
  X,
  FileSpreadsheet,
  Settings,
  AlertCircle,
  Database,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Lock,
  LayoutGrid,
  Sun,
  Moon,
  FileDown
} from "lucide-react";
import { Campaign, PartnerLead, DiscoverRequest } from "./types.js";
import { GlobalDirectory } from "./components/GlobalDirectory.js";
import { GroundingCenter } from "./components/GroundingCenter.js";
import { OutreachTracker } from "./components/OutreachTracker.js";
import { CountriesView } from "./components/CountriesView.js";
import { AnalyticsView } from "./components/AnalyticsView.js";
import { CountrySelector } from "./components/CountrySelector.js";

// Preset lead search templates for the vetting engine matching similar high-capacity resellers
const LEAD_TYPE_PRESETS = [
  { id: "crm_erp", label: "CRM & ERP (Odoo/Zoho) partners", desc: "Consultants already delivering other business apps and eager to bundle HR modules." },
  { id: "it_msp", label: "General IT service providers", desc: "Rival-free system admins and managed services with strong, trusted local client bases." },
  { id: "payroll", label: "Payroll service bureaus", desc: "Outsourced payroll bureaus looking to vend comprehensive client portals." },
  { id: "digital", label: "Digital Transformation consultancies", desc: "Integrators helping mid-tier Mittelstand/SMEs modernise workspace suites." },
  { id: "competitor", label: "Competitor platform resellers", desc: "Existing BambooHR/Sage/Workday distributors prime for a higher-margin, open alternative search." }
];

const PROMPT_TEMPLATE = (country: string, focus: string) => `You are a partner scouting analyst for OrangeHRM, the world's most widely used open-source HR software (5M+ users, 100+ countries).

Research 10 companies in ${country} that would make strong OrangeHRM reseller partners. Target: established IT firms that already source, sell, implement, and support HR software, IS systems, or ERP solutions to local businesses.

\${focus ? 'Special focus: ' + focus : ''}

Return ONLY a valid JSON array — no markdown, no explanation, no code fences. Each object must have exactly these fields:
[
  {
    "company_name": "string",
    "country": "\${country}",
    "city": "string",
    "founded": "year as string",
    "employees": "e.g. 200-500",
    "revenue_est": "e.g. ~$20M or Not public",
    "gross_margin_est": "e.g. ~35-45% or Not available",
    "fit_score": 82,
    "fit_tier": "high",
    "firm_size_segment": "SME or Mid-Market or Enterprise",
    "existing_partners": "comma-separated vendor names",
    "industries": "comma-separated industries",
    "reputation_status": "Reputable or Rising or Institutional",
    "reputation_details": "1-2 sentences about market reputation",
    "strategic_fit": "2-3 sentences about why OrangeHRM is a good fit for this partner",
    "outreach_status": "new",
    "pros": "one strength per line, \\n separated",
    "cons": "one risk per line, \\n separated",
    "notes": "2-3 sentence partnership recommendation",
    "sources": [{"title": "source name", "url": "https://..."}]
  }
]

Rules:
- fit_tier must be "high" (70-100), "mid" (40-69), or "low" (0-39)
- fit_score 0-100 based on partner viability
- firm_size_segment: "SME" (<100 employees), "Mid-Market" (100-500), "Enterprise" (500+)
- reputation_status: "Reputable" (well-known), "Rising" (growing), "Institutional" (legacy/established)
- Use "Not public" for unknown financials. Be honest — do not invent figures
- Include real, verifiable companies with track records
- sources should include at least one URL per company if available\`;

export default function App() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [selectedLead, setSelectedLead] = useState<PartnerLead | null>(null);
  const [customVettingNotes, setCustomVettingNotes] = useState<string>("");
  const [isSavingNotes, setIsSavingNotes] = useState<boolean>(false);
  const [notesFeedback, setNotesFeedback] = useState<string>("");

  // Tab View State Control: 'scout' | 'directory' | 'grounding' | 'outreach' | 'countries' | 'analytics'
  const [activeWorkspaceTab, setActiveWorkspaceTab] = useState<"scout" | "directory" | "grounding" | "outreach" | "countries" | "analytics">("scout");

  // Department-wide active role: "alliances" | "bdr" | "risk"
  const [activeDepartmentRole, setActiveDepartmentRole] = useState<"alliances" | "bdr" | "risk">("alliances");

  // Country filtering state for directory ledger redirection
  const [filterCountry, setFilterCountry] = useState<string>("All");

  // Settings states
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [clientApiKey, setClientApiKey] = useState(localStorage.getItem("psGeminiKey") || "");
  const [clientApiModel, setClientApiModel] = useState(localStorage.getItem("psGeminiModel") || "gemini-2.0-flash");

  // Theme support
  const [theme, setTheme] = useState<"light" | "dark">(
    () => (localStorage.getItem("psTheme") as "light" | "dark") || "light"
  );

  // Batch Mode states
  const [isBatchMode, setIsBatchMode] = useState(false);
  const [batchCountries, setBatchCountries] = useState<string[]>([]);
  const [batchActiveIndex, setBatchActiveIndex] = useState(-1);
  const [isBatching, setIsBatching] = useState(false);
  const [batchProgress, setBatchProgress] = useState(0);

  // Paste Fallback manual AI states
  const [showPasteFallback, setShowPasteFallback] = useState(false);
  const [pasteInput, setPasteInput] = useState("");
  const [manualScoutCountry, setManualScoutCountry] = useState("");

  // Sync theme
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
      root.setAttribute("data-theme", "dark");
    } else {
      root.classList.remove("dark");
      root.setAttribute("data-theme", "light");
    }
    localStorage.setItem("psTheme", theme);
  }, [theme]);

  const selectDepartmentRole = (role: "alliances" | "bdr" | "risk") => {
    setActiveDepartmentRole(role);
    if (role === "alliances") {
      setActiveWorkspaceTab("scout");
    } else if (role === "bdr") {
      setActiveWorkspaceTab("outreach");
    } else if (role === "risk") {
      setActiveWorkspaceTab("grounding");
    }
  };

  // Shared helper: export selected leads list to Comma-Separated Values (CSV)
  const exportToCSV = (leadsList: PartnerLead[], sheetName: string) => {
    const headers = [
      "Company Name",
      "HQ Location",
      "Employee Size",
      "Estimated Revenue",
      "Calculated GPM",
      "Financial Status",
      "Competitors Represented",
      "Reputation Standing",
      "Strategic Why-OrangeHRM Pitch",
      "Sources Citations",
      "Custom Vetting Notes"
    ].join(",");

    const rows = leadsList.map(lead => {
      const escapedNotes = ((lead as any).customNotes || "").replace(/"/g, '""');
      const escapedWhy = (lead.strategicFit?.whyOrangeHRM || "").replace(/"/g, '""');
      const comps = (lead.trackRecord?.competitors || []).join("; ");
      const citText = (lead.sources || []).map(s => `${s.title} (${s.url})`).join("; ");

      return [
        `"${lead.name.replace(/"/g, '""')}"`,
        `"${lead.hqLocation.replace(/"/g, '""')}"`,
        `"${lead.employeeSize.replace(/"/g, '""')}"`,
        `"${lead.financials?.revenue || ''}"`,
        `"${lead.financials?.gpm || ''}"`,
        `"${lead.financials?.status || ''}"`,
        `"${comps.replace(/"/g, '""')}"`,
        `"${lead.reputation?.status || ''}"`,
        `"${escapedWhy}"`,
        `"${citText.replace(/"/g, '""')}"`,
        `"${escapedNotes}"`
      ].join(",");
    });

    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers, ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `${sheetName.replace(/\s+/g, '_')}_Leads_Dossier_Export.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Shared helper: export deep partner recruitment BRIEF to elegant print PDF layout
  const handleExportPDF = (lead: PartnerLead, campName: string) => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) return;
    
    printWindow.document.write(`
      <html>
        <head>
          <title>Partner briefing: ${lead.name}</title>
          <link rel="preconnect" href="https://fonts.googleapis.com">
          <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
          <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,400&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap" rel="stylesheet">
          <style>
            body {
              font-family: 'Inter', sans-serif;
              color: #1A1A1B;
              background-color: #FFFFFF;
              padding: 45px;
              max-width: 820px;
              margin: 0 auto;
              line-height: 1.5;
            }
            .header {
              border-bottom: 3px double #C2B6A6;
              padding-bottom: 20px;
              margin-bottom: 30px;
              display: flex;
              justify-content: space-between;
              align-items: flex-end;
            }
            .title-group h1 {
              font-family: 'Playfair Display', serif;
              font-size: 28px;
              font-weight: 700;
              color: #1A1A1B;
              margin: 0 0 4px 0;
            }
            .subtitle {
              font-size: 11px;
              text-transform: uppercase;
              letter-spacing: 2.5px;
              color: #EF6C00;
              font-weight: bold;
            }
            .meta-value {
              font-family: 'JetBrains Mono', monospace;
              font-size: 10.5px;
              color: #514F4A;
              text-align: right;
              line-height: 1.4;
            }
            .dossier-card {
              border: 1px solid #EBE4D8;
              background-color: #FDFBF7;
              border-radius: 12px;
              padding: 28px;
              margin-bottom: 24px;
            }
            .lead-title {
              font-family: 'Playfair Display', serif;
              font-size: 24px;
              font-weight: 700;
              color: #1A1A1B;
              margin: 0 0 8px 0;
            }
            .lead-desc {
              font-size: 13.5px;
              color: #514F4A;
              margin-bottom: 24px;
              line-height: 1.6;
              font-style: italic;
            }
            .metrics-grid {
              display: grid;
              grid-template-cols: repeat(4, 1fr);
              gap: 12px;
              margin-bottom: 24px;
            }
            .metric-box {
              background-color: #FAF6F0;
              border: 1px solid #EBE4D8;
              padding: 12px;
              border-radius: 8px;
              text-align: center;
            }
            .metric-label {
              font-size: 9px;
              text-transform: uppercase;
              letter-spacing: 1.2px;
              color: #827F78;
              margin-bottom: 4px;
              font-weight: bold;
            }
            .metric-val {
              font-family: 'JetBrains Mono', monospace;
              font-size: 12px;
              font-weight: bold;
              color: #1A1A1B;
            }
            .section-title {
              font-size: 11.5px;
              text-transform: uppercase;
              letter-spacing: 1.5px;
              font-weight: bold;
              padding-bottom: 6px;
              border-bottom: 1px solid #EBE4D8;
              margin: 28px 0 12px 0;
              color: #EF6C00;
            }
            p.text {
              font-size: 12.5px;
              color: #2F2E2C;
              line-height: 1.6;
              margin-top: 0;
            }
            .sources-list {
              font-size: 11px;
              margin-top: 10px;
            }
            .source-item {
              padding: 10px;
              background-color: #FAF6F0;
              border: 1px solid #EBE4D8;
              border-radius: 6px;
              margin-bottom: 6px;
            }
            .notes-section {
              background-color: #FFF9F2;
              border: 1.5px dashed #EF6C00;
              padding: 16px;
              border-radius: 10px;
              font-size: 12.5px;
              color: #1A1A1B;
              line-height: 1.5;
            }
            .footer {
              margin-top: 60px;
              text-align: center;
              font-size: 9px;
              color: #827F78;
              border-top: 1px solid #EBE4D8;
              padding-top: 20px;
            }
            @media print {
              body {
                padding: 15px;
              }
              .no-print {
                display: none !important;
              }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="title-group">
              <span class="subtitle">OrangeHRM Channel Strategic intelligence</span>
              <h1>PARTNER RECRUITMENT BRIEF</h1>
            </div>
            <div class="meta-value">
              CAMPAIGN: ${campName}<br>
              TIMEFRAME: ${new Date().toLocaleDateString()}<br>
              CLASSIFICATION: CONFIDENTIAL BOARD STUDY
            </div>
          </div>

          <div class="dossier-card">
            <div class="lead-title">${lead.name}</div>
            <div class="lead-desc">"${lead.description}"</div>

            <div class="metrics-grid">
              <div class="metric-box">
                <div class="metric-label">HQ Location</div>
                <div class="metric-val" style="font-family: inherit;">${lead.hqLocation}</div>
              </div>
              <div class="metric-box">
                <div class="metric-label">Employee Size</div>
                <div class="metric-val" style="font-family: inherit;">${lead.employeeSize}</div>
              </div>
              <div class="metric-box">
                <div class="metric-label">Est. Revenue</div>
                <div class="metric-val">${lead.financials?.revenue || "Confidential Services"}</div>
              </div>
              <div class="metric-box">
                <div class="metric-label">Estimated GPM</div>
                <div class="metric-val" style="color: #EF6C00;">${lead.financials?.gpm || "N/A"}</div>
              </div>
            </div>

            <div class="section-title">Strategic Rationale & Competitive Footprint</div>
            <p class="text">
              <strong>Current Competitor Networks:</strong> ${lead.trackRecord?.competitors?.join(", ") || "None (True independent / Rival-Free)."}
              <span style="font-size: 11px; display: block; color: #827F78; margin-top: 4px;">
                * Direct brand custom implementation channels: ${lead.trackRecord?.partnershipCount || 0} setups verified.
              </span>
            </p>

            <div class="section-title">Corporate Pitch Vector & Strategic Position</div>
            <p class="text" style="background-color: #FCF5EB; padding: 14px; border-radius: 8px; border-left: 3px solid #EF6C00; font-family: inherit;">
              ${lead.strategicFit?.whyOrangeHRM}
            </p>

            <div class="section-title">Audit Reputation Standing</div>
            <p class="text">
              <strong>Reputation Class:</strong> ${lead.reputation?.status || "Vetted"}<br>
              ${lead.reputation?.details}
            </p>

            ${(lead as any).customNotes ? `
              <div class="section-title">Internal Vetting Remarks (Scouts Team Log)</div>
              <div class="notes-section">
                <strong>Vetting Log Notes:</strong><br>
                ${(lead as any).customNotes}
              </div>
            ` : ""}

            <div class="section-title">Verified Proof of Life Sourcing Citations</div>
            <div class="sources-list">
              ${(lead.sources && lead.sources.length > 0) ? lead.sources.map(src => `
                <div class="source-item">
                  <strong>${src.title}</strong><br>
                  <span style="font-family: 'JetBrains Mono', monospace; font-size: 10px; color: #EF6C00;">${src.url}</span>
                </div>
              `).join("") : `<div class="source-item">Verified via local business registers and digital tech surveys.</div>`}
            </div>

          </div>

          <div class="footer">
            OrangeHRM Partner Intelligence Division • Private Internal Consult Document. For Team Use Only.
          </div>

          <script>
            window.onload = function() {
              window.print();
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleUpdateOutreachStatus = async (campaignId: string, leadId: string, status: string) => {
    try {
      const res = await fetch(`/api/campaigns/${campaignId}/leads/${leadId}/outreach`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        // Fetch background changes silently to keep client sync
        fetchCampaigns(false);
      }
    } catch (err) {
      console.error("Failed to post outreach status", err);
    }
  };

  const handleCardOutreachStatusChange = async (leadId: string, status: string) => {
    if (!selectedCampaign) return;
    await handleUpdateOutreachStatus(selectedCampaign.id, leadId, status);
  };

  const handleSaveCardNotes = async (leadId: string) => {
    if (!selectedCampaign) return;
    const notesStr = cardNotesState[leadId] !== undefined ? cardNotesState[leadId] : "";
    setCardNotesStatus(prev => ({ ...prev, [leadId]: "Syncing..." }));
    try {
      const res = await fetch(`/api/campaigns/${selectedCampaign.id}/leads/${leadId}/notes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ CustomNotes: notesStr })
      });
      if (res.ok) {
        setCardNotesStatus(prev => ({ ...prev, [leadId]: "Draft Synced! ✅" }));
        fetchCampaigns(false);
        setTimeout(() => {
          setCardNotesStatus(prev => ({ ...prev, [leadId]: "" }));
        }, 3000);
      } else {
        setCardNotesStatus(prev => ({ ...prev, [leadId]: "Sync Error ❌" }));
      }
    } catch (err) {
      console.error(err);
      setCardNotesStatus(prev => ({ ...prev, [leadId]: "Network Error ❌" }));
    }
  };

  // Creation Form State
  const [targetCountryOption, setTargetCountryOption] = useState<string>("Germany");
  const [customCountryInput, setCustomCountryInput] = useState<string>("");
  const [customCampaignName, setCustomCampaignName] = useState<string>("");
  const [selectedPresets, setSelectedPresets] = useState<string[]>(["hris", "digital"]);
  const [searchDepth, setSearchDepth] = useState<"fast" | "comprehensive">("comprehensive");
  const [isSpawning, setIsSpawning] = useState<boolean>(false);
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);

  // Filters and Sorting
  const [selectedReputationFilter, setSelectedReputationFilter] = useState<string>("All");
  const [selectedCompetitorFilter, setSelectedCompetitorFilter] = useState<string>("All");
  const [selectedNeutralityFilter, setSelectedNeutralityFilter] = useState<string>("All");
  const [selectedSegmentFilter, setSelectedSegmentFilter] = useState<string>("All");
  const [selectedLeadSort, setSelectedLeadSort] = useState<string>("default");

  // Card-level expandable BDR edits and notes state
  const [expandedCardNotes, setExpandedCardNotes] = useState<Record<string, boolean>>({});
  const [cardNotesState, setCardNotesState] = useState<Record<string, string>>({});
  const [cardNotesStatus, setCardNotesStatus] = useState<Record<string, string>>({});

  const toggleCardNotesExpand = (leadId: string) => {
    setExpandedCardNotes(prev => ({ ...prev, [leadId]: !prev[leadId] }));
  };

  const handleCardNotesChange = (leadId: string, val: string) => {
    setCardNotesState(prev => ({ ...prev, [leadId]: val }));
  };

  // Health / Agent System Stats
  const [serverStatus, setServerStatus] = useState<{
    status: string;
    timestamp: string;
    aiEngine: string;
    hasSerper: boolean;
  } | null>(null);

  // Poll Interval Reference for tracking active campaigns
  const pollIntervalRef = useRef<number | null>(null);

  // Fetch initial campaign state and health
  useEffect(() => {
    fetchHealthStatus();
    fetchCampaigns(true); // first load auto-selects the first completed or processing campaign
    
    // Start active polling for progress updates
    pollIntervalRef.current = window.setInterval(() => {
      fetchCampaigns(false);
    }, 4000);

    return () => {
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current);
      }
    };
  }, []);

  // Fetch API Health
  const fetchHealthStatus = async () => {
    try {
      const res = await fetch("/api/health");
      if (res.ok) {
        const data = await res.json();
        setServerStatus(data);
      }
    } catch (e) {
      console.error("Health check error", e);
      // Fetch Campaigns
  const fetchCampaigns = async (autoSelect: boolean = false) => {
    try {
      const res = await fetch("/api/campaigns");
      if (res.ok) {
        const data: Campaign[] = await res.json();
        setCampaigns(data);

        if (data.length === 0) {
          // Check for legacy import
          const oldData = localStorage.getItem("ohrmLeads");
          const newData = localStorage.getItem("partnerScoutData");
          let rawLeads: any[] = [];
          if (newData) {
            try { rawLeads = JSON.parse(newData); } catch (e) {}
          } else if (oldData) {
            try { rawLeads = JSON.parse(oldData); } catch (e) {}
          }

          if (Array.isArray(rawLeads) && rawLeads.length > 0) {
            console.log("Found legacy lead data. Migrating to server database...");
            const mappedLeads = rawLeads.map((l: any, idx: number) => {
              const cleanRevenue = l.revenue_est || l.revenue || "Not public";
              const cleanGpm = l.gross_margin_est || l.gpm || "Not available";
              const cleanStatus = l.financial_status || (l.status === "Listed" ? "Listed" : "Private");
              const cleanRep = l.reputation_status || l.reputation?.status || "Reputable";
              const cleanRepDetails = l.reputation_details || l.reputation?.details || "";
              const cleanWhy = l.strategic_fit || l.strategicFit?.whyOrangeHRM || l.notes || "";
              const cleanOutreach = l.outreach_status || l.outreachStatus || "not_contacted";
              const cleanCompetitors = l.existing_partners ? l.existing_partners.split(",").map((x: any) => x.trim()).filter(Boolean) : (l.trackRecord?.competitors || []);
              
              return {
                id: l.id || `lead-migrated-${idx}-${Date.now()}`,
                name: l.company_name || l.name || "Migrated Partner",
                hqLocation: l.hqLocation || `${l.city || ""}, ${l.country || ""}`.trim().replace(/^,\s*/, "") || "Multi-Region",
                employeeSize: l.employees || l.employeeSize || "Unknown",
                firmSizeSegment: l.firm_size_segment || l.firmSizeSegment || (l.employees && parseInt(l.employees) > 500 ? "Enterprise" : "SME"),
                description: l.description || l.notes || "Migrated lead record.",
                socialLinks: {
                  website: l.website || l.socialLinks?.website || "https://google.com",
                  linkedin: l.linkedin || l.socialLinks?.linkedin || "https://linkedin.com"
                },
                financials: { revenue: cleanRevenue, gpm: cleanGpm, status: cleanStatus },
                trackRecord: { partnershipCount: cleanCompetitors.length, competitors: cleanCompetitors },
                reputation: { status: cleanRep, details: cleanRepDetails },
                strategicFit: { whyOrangeHRM: cleanWhy },
                sources: l.sources || [],
                customNotes: l.notes || l.customNotes || "",
                outreachStatus: cleanOutreach,
                createdAt: l.created_at || l.createdAt || new Date().toISOString()
              };
            });

            try {
              const importResp = await fetch("/api/campaigns/import", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  name: "Migrated Legacy Campaign",
                  country: mappedLeads[0].hqLocation.split(",").pop()?.trim() || "Multi-Region",
                  leads: mappedLeads
                })
              });

              if (importResp.ok) {
                const importData = await importResp.json();
                setCampaigns([importData.campaign]);
                if (autoSelect) {
                  setSelectedCampaign(importData.campaign);
                }
              }
            } catch (err) {
              console.error("Failed to migrate legacy leads", err);
            }
          }
        } else if (autoSelect && data.length > 0) {
          // Find if there is an active processing campaign, otherwise choose the first one
          const active = data.find(c => c.status === "processing") || data[0];
          setSelectedCampaign(active);
        } else if (selectedCampaign) {
          // Refresh the currently selected campaign reference to update dynamic steps and progress
          const updated = data.find(c => c.id === selectedCampaign.id);
          if (updated) {
            setSelectedCampaign(updated);
            // If the selected lead is active, refresh its details if notes are not being edited actively
            if (selectedLead) {
              const updatedLead = updated.leads.find(l => l.id === selectedLead.id);
              if (updatedLead) {
                // Only update lead if the user isn't modifying notes right now
                setSelectedLead(updatedLead);
              }
            }
          }
        }
      }
    } catch (e) {
      console.error("Error fetching campaigns", e);
    }
  };

  // Create Campaign Vetting Run
  const handleLaunchCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    const resolvedCountry = targetCountryOption === "custom" ? customCountryInput.trim() : targetCountryOption;

    // Resolve active search terms based on selected presets
    const chosenTypes = LEAD_TYPE_PRESETS
      .filter(p => selectedPresets.includes(p.id))
      .map(p => `${p.label} [Country]`);

    if (chosenTypes.length === 0) {
      alert("Please choose at least one Lead Vetting preset query.");
      return;
    }

    const apiKey = localStorage.getItem("psGeminiKey") || undefined;
    const apiModel = localStorage.getItem("psGeminiModel") || undefined;

    if (isBatchMode && batchCountries.length > 0) {
      setIsFormOpen(false);
      setIsBatching(true);
      setBatchProgress(0);
      setBatchActiveIndex(0);

      for (let i = 0; i < batchCountries.length; i++) {
        const countryName = batchCountries[i];
        setBatchActiveIndex(i);
        setBatchProgress(Math.round((i / batchCountries.length) * 100));

        try {
          const payload = {
            country: countryName,
            campaignName: `${countryName} Channel Vetting`,
            leadTypes: chosenTypes,
            depth: searchDepth,
            apiKey,
            apiModel
          };

          const response = await fetch("/api/campaigns", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
          });

          if (response.ok) {
            const spawnedCampaign: Campaign = await response.json();
            setCampaigns(prev => [spawnedCampaign, ...prev]);
            setSelectedCampaign(spawnedCampaign);

            // Poll campaign status until completed or failed
            let completed = false;
            while (!completed) {
              await new Promise(r => setTimeout(r, 2000));
              const pollRes = await fetch(`/api/campaigns/${spawnedCampaign.id}`);
              if (pollRes.ok) {
                const pollCamp: Campaign = await pollRes.json();
                setCampaigns(prev => prev.map(c => c.id === pollCamp.id ? pollCamp : c));
                if (!selectedCampaign || selectedCampaign.id === pollCamp.id) {
                  setSelectedCampaign(pollCamp);
                }
                if (pollCamp.status === "completed" || pollCamp.status === "failed") {
                  completed = true;
                }
              } else {
                completed = true;
              }
            }
          }
        } catch (err) {
          console.error(`Error scouting batch country ${countryName}`, err);
        }
      }

      setBatchProgress(100);
      setIsBatching(false);
      setBatchActiveIndex(-1);
      setBatchCountries([]);
      setIsBatchMode(false);
      alert(`Batch Vetting Completed! Scouted ${batchCountries.length} countries.`);
      fetchCampaigns(false);
      return;
    }

    if (!resolvedCountry) return;
    setIsSpawning(true);

    try {
      const requestPayload = {
        country: resolvedCountry,
        campaignName: customCampaignName.trim() || undefined,
        leadTypes: chosenTypes,
        depth: searchDepth,
        apiKey,
        apiModel
      };

      const res = await fetch("/api/campaigns", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestPayload)
      });

      if (res.ok) {
        const spawnedCampaign: Campaign = await res.json();
        // Update local list instantly
        setCampaigns(prev => [spawnedCampaign, ...prev]);
        setSelectedCampaign(spawnedCampaign);
        
        // Reset state
        setTargetCountryOption("Germany");
        setCustomCountryInput("");
        setCustomCampaignName("");
        setIsFormOpen(false);
      }
    } catch (e) {
      console.error("Failed to spawn search", e);
    } finally {
      setIsSpawning(false);
    }
  };

  // Delete Campaign
  const handleDeleteCampaign = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Are you sure you want to delete this vetting session and all collected intelligence dossiers?")) {
      return;
    }

    try {
      const res = await fetch(`/api/campaigns/${id}`, { method: "DELETE" });
      if (res.ok) {
        setCampaigns(prev => prev.filter(c => c.id !== id));
        if (selectedCampaign?.id === id) {
          setSelectedCampaign(null);
          setSelectedLead(null);
        }
      }
    } catch (err) {
      console.error("Delete campaign error", err);
    }
  };

  const handleClearAllCampaigns = async () => {
    if (!confirm("Are you absolutely sure you want to delete ALL vetting campaigns and start from a completely clean slate (zero)? This will wipe all current files and CRM notes.")) {
      return;
    }

    try {
      const res = await fetch("/api/campaigns", { method: "DELETE" });
      if (res.ok) {
        setCampaigns([]);
        setSelectedCampaign(null);
        setSelectedLead(null);
      }
    } catch (err) {
      console.error("Clear all campaigns error", err);
    }
  };

  const handleSaveSettings = (key: string, model: string) => {
    localStorage.setItem("psGeminiKey", key);
    localStorage.setItem("psGeminiModel", model);
    setClientApiKey(key);
    setClientApiModel(model);
    setIsSettingsOpen(false);
    fetchHealthStatus();
  };

  const downloadCSVTemplate = () => {
    const COLS = ['company_name', 'country', 'city', 'founded', 'employees', 'revenue_est', 'gross_margin_est', 'fit_score', 'fit_tier', 'firm_size_segment', 'existing_partners', 'industries', 'reputation_status', 'reputation_details', 'strategic_fit', 'outreach_status', 'pros', 'cons', 'notes', 'outreach_notes'];
    const rows = [
      COLS.join(','), 
      'Example Corp,Germany,Berlin,2010,200-500,~$30M,~35-45%,75,high,Mid-Market,"SAP, Microsoft Dynamics","Manufacturing, Retail",Reputable,Well-known ERP partner,Strong candidate for DACH region,new,"Strong ERP track record\nEstablished client base","Revenue not public","Strong candidate for DACH region.",'
    ];
    const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + rows.join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "orangehrm-partner-template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (ev) => {
      const result = ev.target?.result as string;
      if (!result) return;
      
      const lines = result.split("\n").filter(l => l.trim());
      const parseLine = (line: string) => {
        const res = [];
        const re = /(?:^|,)("(?:[^"]|"")*"|[^,]*)/g;
        let m;
        while ((m = re.exec(line))) {
          let v = m[1];
          if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1).replace(/""/g, '"');
          res.push(v);
        }
        return res;
      };

      const headers = parseLine(lines[0]).map(h => h.trim().toLowerCase());
      const importedLeads: any[] = [];

      for (let i = 1; i < lines.length; i++) {
        const vals = parseLine(lines[i]);
        if (!vals.length) continue;
        const row: Record<string, string> = {};
        headers.forEach((h, j) => {
          row[h] = (vals[j] || "").trim();
        });
        if (!row.company_name) continue;

        const cleanRevenue = row.revenue_est || row.revenue || "Not public";
        const cleanGpm = row.gross_margin_est || row.gpm || "Not available";
        const cleanStatus = row.financial_status || (row.status === "Listed" ? "Listed" : "Private");
        const cleanRep = row.reputation_status || "Reputable";
        const cleanRepDetails = row.reputation_details || "";
        const cleanWhy = row.strategic_fit || row.why_orangehrm || "";
        const cleanOutreach = row.outreach_status || "not_contacted";
        const cleanCompetitors = row.existing_partners ? row.existing_partners.split(",").map(x => x.trim()).filter(Boolean) : [];

        importedLeads.push({
          id: `lead-imported-${i}-${Date.now()}`,
          name: row.company_name,
          hqLocation: `${row.city || ""}, ${row.country || ""}`.trim().replace(/^,\s*/, ""),
          employeeSize: row.employees || "Unknown",
          firmSizeSegment: row.firm_size_segment || (row.employees && parseInt(row.employees) > 500 ? "Enterprise" : "SME"),
          description: row.description || row.notes || "Imported lead record.",
          socialLinks: {
            website: row.website || "https://google.com",
            linkedin: row.linkedin || "https://linkedin.com"
          },
          financials: {
            revenue: cleanRevenue,
            gpm: cleanGpm,
            status: cleanStatus
          },
          trackRecord: {
            partnershipCount: cleanCompetitors.length,
            competitors: cleanCompetitors
          },
          reputation: {
            status: cleanRep,
            details: cleanRepDetails
          },
          strategicFit: {
            whyOrangeHRM: cleanWhy
          },
          sources: [],
          customNotes: row.notes || row.custom_notes || "",
          outreachStatus: cleanOutreach,
          createdAt: new Date().toISOString()
        });
      }

      if (importedLeads.length === 0) {
        alert("No valid leads found in CSV.");
        return;
      }

      try {
        const res = await fetch("/api/campaigns/import", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: `Imported Roster — ${new Date().toLocaleDateString()}`,
            country: importedLeads[0].hqLocation.split(",").pop()?.trim() || "Multi-Region",
            leads: importedLeads
          })
        });

        if (res.ok) {
          alert(`Successfully imported ${importedLeads.length} leads!`);
          fetchCampaigns(false);
        } else {
          alert("Failed to import leads to backend.");
        }
      } catch (err) {
        console.error(err);
        alert("Error posting imported campaign.");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const handleParsePaste = async () => {
    if (!pasteInput.trim()) {
      alert("Please paste a JSON array first.");
      return;
    }

    try {
      const match = pasteInput.match(/\[[\s\S]*\]/);
      const jsonText = match ? match[0] : pasteInput;
      
      const arr = JSON.parse(jsonText);
      if (!Array.isArray(arr)) {
        alert("The pasted content is not a valid JSON array.");
        return;
      }

      const countryName = manualScoutCountry || "Imported Region";
      const mappedLeads = arr.map((l: any, i: number) => ({
        id: l.id || `lead-paste-${i}-${Date.now()}`,
        name: l.company_name || l.name || "Unnamed Partner",
        hqLocation: l.city ? `\${l.city}, \${l.country || countryName}` : (l.hqLocation || countryName),
        founded: String(l.founded || ""),
        employeeSize: l.employees || l.employeeSize || "10-50",
        financials: {
          revenue: l.revenue_est || (l.financials?.revenue || "Not public"),
          gpm: l.gross_margin_est || (l.financials?.gpm || "Not available")
        },
        fitScore: Math.min(100, Math.max(0, parseInt(l.fit_score || l.fitScore) || 70)),
        fitTier: l.fit_tier || l.fitTier || (parseInt(l.fit_score || l.fitScore) >= 70 ? "high" : parseInt(l.fit_score || l.fitScore) >= 40 ? "mid" : "low"),
        firmSizeSegment: l.firm_size_segment || l.firmSizeSegment || "SME",
        trackRecord: {
          competitors: Array.isArray(l.existing_partners) 
            ? l.existing_partners 
            : typeof l.existing_partners === "string" 
              ? l.existing_partners.split(",").map((x: string) => x.trim()).filter(Boolean)
              : [],
          industries: Array.isArray(l.industries)
            ? l.industries
            : typeof l.industries === "string"
              ? l.industries.split(",").map((x: string) => x.trim()).filter(Boolean)
              : []
        },
        reputation: {
          status: l.reputation_status || (l.reputation?.status || "Reputable"),
          details: l.reputation_details || (l.reputation?.details || "")
        },
        strategicFit: {
          whyOrangeHRM: l.strategic_fit || (l.strategicFit?.whyOrangeHRM || "")
        },
        outreachStatus: l.outreach_status || l.outreachStatus || "new",
        pros: Array.isArray(l.pros) 
          ? l.pros 
          : typeof l.pros === "string" 
            ? l.pros.split("\n").map((x: string) => x.trim()).filter(Boolean)
            : [],
        cons: Array.isArray(l.cons)
          ? l.cons
          : typeof l.cons === "string"
            ? l.cons.split("\n").map((x: string) => x.trim()).filter(Boolean)
            : [],
        description: l.notes || l.description || "Parsed manual lead dossier.",
        sources: Array.isArray(l.sources) 
          ? l.sources.map((s: any) => ({ title: s.title || "Source", url: s.url || "" }))
          : [],
        pitchEmail: l.pitch_email || l.pitchEmail || "",
        outreachNotes: l.outreach_notes || l.outreachNotes || ""
      }));

      const importResponse = await fetch("/api/campaigns/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: `\${countryName} Manual Scout`,
          country: countryName,
          leads: mappedLeads
        })
      });

      if (importResponse.ok) {
        const importData = await importResponse.json();
        setCampaigns(prev => [importData.campaign, ...prev]);
        setSelectedCampaign(importData.campaign);
        setShowPasteFallback(false);
        setPasteInput("");
        setManualScoutCountry("");
        alert(`Successfully imported manual campaign for \${countryName}!`);
      } else {
        alert("Failed to save manual campaign to the database.");
      }
    } catch (err: any) {
      alert(`JSON parsing failed: \${err.message}`);
    }
  };

  const handleExportDOCX = async (leadsList: PartnerLead[]) => {
    if (leadsList.length === 0) {
      alert("No leads to export.");
      return;
    }
    
    let zipObj = (window as any).JSZip;
    if (!zipObj) {
      const script = document.createElement("script");
      script.src = "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js";
      script.async = true;
      document.body.appendChild(script);
      
      await new Promise<void>((resolve) => {
        script.onload = () => {
          zipObj = (window as any).JSZip;
          resolve();
        };
      });
    }

    if (!zipObj) {
      alert("Failed to load JSZip from CDN. Please check your internet connection.");
      return;
    }

    const escXml = (s: string) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

    function p(text: string, opts: any = {}) {
      const bold = opts.bold ? "<w:b/>" : "";
      const color = opts.color ? `<w:color w:val="${opts.color}"/>` : "";
      const size = opts.size ? `<w:sz w:val="${opts.size}"/><w:szCs w:val="${opts.size}"/>` : "";
      return `<w:p><w:pPr>${opts.heading ? `<w:pStyle w:val="Heading${opts.heading}"/>` : ""}</w:pPr><w:r><w:rPr>${bold}${color}${size}</w:rPr><w:t xml:space="preserve">${escXml(text)}</w:t></w:r></w:p>`;
    }

    let body = "";
    body += p("OrangeHRM Partner Scout Dossier", { heading: 1 });
    body += p(`Generated: ${new Date().toLocaleDateString()} · ${leadsList.length} leads`, { color: "666666", size: 20 });
    body += "<w:p/>";

    leadsList.forEach(c => {
      body += p(c.name, { heading: 2 });
      body += p(`${c.hqLocation} · Size: ${c.employeeSize} · Segment: ${c.firmSizeSegment} · Fit: ${c.financials?.status || "Private"}`, { color: "666666", size: 20 });
      body += p(`Employees: ${c.employeeSize} | Revenue: ${c.financials?.revenue || "—"} | GPM: ${c.financials?.gpm || "—"}`, { size: 20 });
      if (c.trackRecord?.competitors?.length) {
        body += p("Rivals Represented: " + c.trackRecord.competitors.join(", "), { size: 20, color: "c8900a" });
      } else {
        body += p("Rivals Represented: None (Rival-Free)", { size: 20, color: "1a8a3a" });
      }
      if (c.strategicFit?.whyOrangeHRM) body += p("Strategic Fit: " + c.strategicFit.whyOrangeHRM, { size: 20, bold: true });
      if ((c as any).customNotes) body += p("Notes: " + (c as any).customNotes, { size: 20, color: "555555" });
      body += "<w:p/>";
    });

    const docXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body>${body}<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr></w:body>
</w:document>`;

    const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`;

    const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

    const wordRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>`;

    const zip = new zipObj();
    zip.file("[Content_Types].xml", contentTypes);
    zip.file("_rels/.rels", rels);
    zip.file("word/document.xml", docXml);
    zip.file("word/_rels/document.xml.rels", wordRels);

    const blob = await zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "orangehrm-partners.docx";
    a.click();
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setSelectedLead(null);
        setIsFormOpen(false);
        setIsSettingsOpen(false);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setActiveWorkspaceTab("scout");
        const input = document.getElementById("scout-country-input");
        if (input) {
          input.focus();
        }
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "e") {
        e.preventDefault();
        if (selectedCampaign && selectedCampaign.leads && selectedCampaign.leads.length > 0) {
          exportToCSV(selectedCampaign.leads, selectedCampaign.name);
        } else {
          const allCompiled = campaigns.flatMap(c => c.leads || []);
          if (allCompiled.length > 0) {
            exportToCSV(allCompiled, "All_Partners_Roster");
          }
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedCampaign, campaigns]);

  // Select Lead Details Drawer
  const handleLeadClick = (lead: PartnerLead) => {
    setSelectedLead(lead);
    setCustomVettingNotes((lead as any).customNotes || "");
    setNotesFeedback("");
  };

  // Save Vetting Notes
  const handleSaveNotes = async () => {
    if (!selectedCampaign || !selectedLead) return;
    setIsSavingNotes(true);
    setNotesFeedback("");

    try {
      const res = await fetch(`/api/campaigns/${selectedCampaign.id}/leads/${selectedLead.id}/notes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ CustomNotes: customVettingNotes })
      });

      if (res.ok) {
        setNotesFeedback("Notes saved securely");
        // Refetch state silently to persist with memory model
        fetchCampaigns(false);
        setTimeout(() => setNotesFeedback(""), 3000);
      } else {
        setNotesFeedback("Error saving notes");
      }
    } catch (err) {
      console.error("Notes post failed", err);
      setNotesFeedback("Network error saving notes");
    } finally {
      setIsSavingNotes(false);
    }
  };

  // Filter & Sort Calculations for Leads
  const getFilteredLeads = () => {
    if (!selectedCampaign) return [];
    let list = [...selectedCampaign.leads];

    // Filter by Reputation status
    if (selectedReputationFilter !== "All") {
      list = list.filter(l => l.reputation?.status === selectedReputationFilter);
    }

    // Filter by firmSizeSegment
    if (selectedSegmentFilter !== "All") {
      list = list.filter(l => l.firmSizeSegment === selectedSegmentFilter);
    }

    // Filter by Competitor
    if (selectedCompetitorFilter !== "All") {
      list = list.filter(l => 
        l.trackRecord?.competitors.some(c => c.toLowerCase().includes(selectedCompetitorFilter.toLowerCase()))
      );
    }

    // Filter by Rival Neutrality
    if (selectedNeutralityFilter === "RivalFree") {
      list = list.filter(l => !l.trackRecord?.competitors || l.trackRecord.competitors.length === 0);
    } else if (selectedNeutralityFilter === "Resellers") {
      list = list.filter(l => l.trackRecord?.competitors && l.trackRecord.competitors.length > 0);
    }

    // Sorting Modes
    if (selectedLeadSort === "partnerships-high") {
      list.sort((a, b) => (b.trackRecord?.partnershipCount || 0) - (a.trackRecord?.partnershipCount || 0));
    } else if (selectedLeadSort === "revenue-estimate") {
      // Crude extract helper for sorting representation
      const extractNum = (str: string) => {
        const clean = str.replace(/[^0-9.]/g, "");
        return parseFloat(clean) || 0;
      };
      list.sort((a, b) => extractNum(b.financials?.revenue) - extractNum(a.financials?.revenue));
    } else if (selectedLeadSort === "growth-potential") {
      // GPM string search sort
      const extractGPM = (str: string) => {
        const clean = str.replace(/[^0-9]/g, "");
        return parseInt(clean) || 0;
      };
      list.sort((a, b) => extractGPM(b.financials?.gpm) - extractGPM(a.financials?.gpm));
    }

    return list;
  };

  // Helper lists for dynamic unique competitors found across currently selected items
  const getCompetitorsList = () => {
    if (!selectedCampaign) return [];
    const set = new Set<string>();
    selectedCampaign.leads.forEach(l => {
      l.trackRecord?.competitors.forEach(c => set.add(c));
    });
    return Array.from(set);
  };

  const activeLeads = getFilteredLeads();
  const competitorsInCampaign = getCompetitorsList();

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 flex flex-col font-sans selection:bg-[#EF6C00]/15 selection:text-[#EF6C00]">
      
      {/* Upper Status Bar - Solid Corporate Brand (OrangeHRM Identity) */}
      <header className="border-b border-slate-200 bg-white px-6 py-4 sticky top-0 z-40 backdrop-blur-md bg-opacity-95 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col xl:flex-row xl:items-center xl:justify-between gap-4">
          
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-[#EF6C00] rounded-xl flex items-center justify-center text-white font-serif font-black text-xl tracking-tight leading-none shadow-md shadow-[#EF6C00]/25">
              O
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif text-xl font-bold tracking-tight text-slate-900">
                  OrangeHRM Partner Intelligence
                </h1>
                <span className="text-[10px] uppercase font-bold tracking-widest bg-emerald-50 text-emerald-800 border border-emerald-200 px-2 py-0.5 rounded-full font-sans">
                  Enterprise Vetting v1.2
                </span>
              </div>
              <p className="text-xs text-slate-500 font-light font-sans">
                Global reselling network auditor powered by Google Gemini 3.5 & real-time search indexing.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Department Role Workspace Selection */}
            <div className="bg-slate-100 border border-slate-200 p-0.5 rounded-lg flex items-center gap-0.5">
              <span className="text-[10px] text-slate-500 font-mono uppercase tracking-wider px-2 font-bold select-none border-r border-slate-200 mr-1 hidden sm:inline">
                Dept Role:
              </span>
              <button
                onClick={() => selectDepartmentRole("alliances")}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                  activeDepartmentRole === "alliances"
                    ? "bg-[#EF6C00] text-white shadow-xs"
                    : "text-slate-600 hover:bg-slate-200/50 hover:text-[#EF6C00]"
                }`}
                title="Manage country campaigns, metrics & strategic reseller fits"
              >
                <Activity className="w-3.5 h-3.5" />
                <span>Global Alliances</span>
              </button>
              <button
                onClick={() => selectDepartmentRole("bdr")}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                  activeDepartmentRole === "bdr"
                    ? "bg-[#EF6C00] text-white shadow-xs"
                    : "text-slate-600 hover:bg-slate-200/50 hover:text-[#EF6C00]"
                }`}
                title="BDR Sales outreach statuses and custom email templates"
              >
                <Briefcase className="w-3.5 h-3.5" />
                <span>BDR Outreach</span>
              </button>
              <button
                onClick={() => selectDepartmentRole("risk")}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                  activeDepartmentRole === "risk"
                    ? "bg-[#EF6C00] text-white shadow-xs"
                    : "text-slate-600 hover:bg-slate-200/50 hover:text-[#EF6C00]"
                }`}
                title="Inspect real proof of life web links, LinkedIn references & sources"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Risk/Audit Desk</span>
              </button>
            </div>

            {/* Health / Agent state banner */}
            <div className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1 flex items-center gap-2 text-xs">
              <span className={`w-1.5 h-1.5 rounded-full ${serverStatus ? 'bg-emerald-600 animate-pulse' : 'bg-amber-500'}`} />
              <span className="font-mono text-slate-500 text-[11px]">
                {serverStatus?.aiEngine || "Connecting to AI Vetting Node..."}
              </span>
              {serverStatus?.hasSerper && (
                <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 text-[9px] font-bold px-1 rounded uppercase tracking-wider">
                  Serper
                </span>
              )}
            </div>

            {/* Theme Toggle Button */}
            <button
              onClick={() => setTheme(prev => (prev === "light" ? "dark" : "light"))}
              className="p-1.5 bg-white dark:bg-[#1e1e1c] border border-slate-200 dark:border-[#333330] hover:bg-slate-50 dark:hover:bg-[#252523] rounded-lg text-slate-600 dark:text-[#a8a69e] hover:text-slate-900 dark:hover:text-[#e8e6e0] transition-colors cursor-pointer focus:outline-none flex items-center justify-center"
              title={theme === "light" ? "Switch to Dark Mode" : "Switch to Light Mode"}
            >
              {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>

            {/* Settings Cog Button */}
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-1.5 bg-white dark:bg-[#1e1e1c] border border-slate-200 dark:border-[#333330] hover:bg-slate-50 dark:hover:bg-[#252523] rounded-lg text-slate-600 dark:text-[#a8a69e] hover:text-slate-900 dark:hover:text-[#e8e6e0] transition-colors cursor-pointer focus:outline-none flex items-center justify-center"
              title="API & Settings"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* CSV Import & Template Buttons */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => document.getElementById("csv-import-header")?.click()}
                className="p-1.5 bg-white dark:bg-[#1e1e1c] border border-slate-200 dark:border-[#333330] hover:bg-slate-50 dark:hover:bg-[#252523] rounded-lg text-slate-600 dark:text-[#a8a69e] hover:text-slate-900 dark:hover:text-[#e8e6e0] transition-colors cursor-pointer focus:outline-none flex items-center gap-1 text-xs"
                title="Import Lead Data CSV"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span className="hidden md:inline font-semibold">Import CSV</span>
              </button>
              <input
                type="file"
                id="csv-import-header"
                accept=".csv"
                style={{ display: "none" }}
                onChange={handleImportCSV}
              />
              <button
                onClick={downloadCSVTemplate}
                className="p-1.5 bg-white dark:bg-[#1e1e1c] border border-slate-200 dark:border-[#333330] hover:bg-slate-50 dark:hover:bg-[#252523] rounded-lg text-slate-600 dark:text-[#a8a69e] hover:text-slate-900 dark:hover:text-[#e8e6e0] transition-colors cursor-pointer focus:outline-none flex items-center gap-1 text-xs"
                title="Download CSV Import Template"
              >
                <FileDown className="w-4 h-4 text-blue-600" />
                <span className="hidden md:inline font-semibold">CSV Template</span>
              </button>
            </div>

            <button
              onClick={() => setIsFormOpen(true)}
              className="bg-[#EF6C00] hover:bg-[#D45F00] transition-colors text-white text-xs font-semibold px-4 py-1.5 rounded-lg flex items-center gap-2 shadow-xs font-sans cursor-pointer focus:outline-none"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Country Scan</span>
            </button>
          </div>

        </div>
      </header>

      {/* Workspace Navigation Tabs - Classy Modern Solid Partner Aesthetic */}
      <div className="bg-white border-b border-slate-200 px-6 py-2 select-none sticky top-[73px] z-30 shadow-3xs">
        <div className="max-w-7xl mx-auto flex flex-wrap gap-6 text-xs font-mono uppercase tracking-wider font-extrabold font-sans">
          <button
            onClick={() => setActiveWorkspaceTab("scout")}
            className={`pb-1.5 pt-1.5 flex items-center gap-1.5 cursor-pointer relative transition-colors ${
              activeWorkspaceTab === "scout" 
                ? "text-[#EF6C00]" 
                : "text-slate-500 hover:text-slate-900"
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Active Campaigns Scout</span>
            {activeWorkspaceTab === "scout" && (
              <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#EF6C00] rounded-full" />
            )}
          </button>

          <button
            onClick={() => setActiveWorkspaceTab("directory")}
            className={`pb-1.5 pt-1.5 flex items-center gap-1.5 cursor-pointer relative transition-colors ${
              activeWorkspaceTab === "directory" 
                ? "text-[#EF6C00]" 
                : "text-slate-500 hover:text-slate-900"
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Global Directory Ledger</span>
            {activeWorkspaceTab === "directory" && (
              <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#EF6C00] rounded-full" />
            )}
          </button>

          <button
            onClick={() => setActiveWorkspaceTab("grounding")}
            className={`pb-1.5 pt-1.5 flex items-center gap-1.5 cursor-pointer relative transition-colors ${
              activeWorkspaceTab === "grounding" 
                ? "text-[#EF6C00]" 
                : "text-slate-500 hover:text-slate-900"
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-emerald-600" />
            <span>Search Grounding Hub</span>
            {activeWorkspaceTab === "grounding" && (
              <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#EF6C00] rounded-full" />
            )}
          </button>

          <button
            onClick={() => setActiveWorkspaceTab("outreach")}
            className={`pb-1.5 pt-1.5 flex items-center gap-1.5 cursor-pointer relative transition-colors ${
              activeWorkspaceTab === "outreach" 
                ? "text-[#EF6C00]" 
                : "text-slate-500 hover:text-slate-900"
            }`}
          >
            <Briefcase className="w-3.5 h-3.5 text-purple-700" />
            <span>Outreach CRM Board</span>
            {activeWorkspaceTab === "outreach" && (
              <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#EF6C00] rounded-full" />
            )}
          </button>

          <button
            onClick={() => setActiveWorkspaceTab("countries")}
            className={`pb-1.5 pt-1.5 flex items-center gap-1.5 cursor-pointer relative transition-colors ${
              activeWorkspaceTab === "countries" 
                ? "text-[#EF6C00]" 
                : "text-slate-500 hover:text-slate-900"
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-sky-600" />
            <span>Regional Observatories</span>
            {activeWorkspaceTab === "countries" && (
              <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#EF6C00] rounded-full" />
            )}
          </button>

          <button
            onClick={() => setActiveWorkspaceTab("analytics")}
            className={`pb-1.5 pt-1.5 flex items-center gap-1.5 cursor-pointer relative transition-colors ${
              activeWorkspaceTab === "analytics" 
                ? "text-[#EF6C00]" 
                : "text-slate-500 hover:text-slate-900"
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 text-[#EF6C00]" />
            <span>Analytics Dashboard</span>
            {activeWorkspaceTab === "analytics" && (
              <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#EF6C00] rounded-full" />
            )}
          </button>
        </div>
      </div>

      {/* Department Workspace Banner Indicator */}
      <div className="bg-slate-50 border-b border-slate-200/80 px-6 py-2 text-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 bg-[#EF6C00]/10 text-[#EF6C00] font-mono font-bold uppercase text-[9px] px-2 py-0.5 rounded-full border border-[#EF6C00]/20">
              ● ACTIVE DEPT OVERLAY
            </span>
            <span className="text-slate-300 font-light select-none">|</span>
            <span className="text-slate-500 font-light font-sans">
              Active View: {activeDepartmentRole === "alliances" ? (
                <span><strong>Global Alliances Workspace</strong> — Auditing vetting campaigns, analyzing gross margins (GPM), and onboarding strategically fit regional resellers.</span>
              ) : activeDepartmentRole === "bdr" ? (
                <span><strong>BDR Outreach Workspace</strong> — Tracking corporate CRM statuses, setting callbacks, and reviewing custom-grounded partner emails.</span>
              ) : (
                <span><strong>Risk Assurance Desktop</strong> — Checking citations, exploring verified proof-of-life domains, and inspecting live LinkedIn corporate profiles.</span>
              )}
            </span>
          </div>
          <span className="text-[10px] font-mono text-[#EF6C00] font-bold uppercase animate-fade-in hidden lg:inline select-none">
            {activeDepartmentRole === "alliances" ? "Strategic Alliances Portal" : activeDepartmentRole === "bdr" ? "BDR Lead Center" : "Risk Assurance Panel"}
          </span>
        </div>
      </div>

      {activeWorkspaceTab === "scout" && (
        <main className="flex-1 max-w-7xl w-full mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in duration-300">
        
        {/* LEFT COLUMN: VETTING CAMPAIGNS & TRACKING (4 Cols) */}
        <div className="lg:col-span-4 space-y-6">
          
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <div className="flex justify-between items-center mb-2">
              <h2 className="font-serif text-lg font-bold text-slate-900 flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#EF6C00]" />
                Discovery Campaigns
              </h2>
              {campaigns.length > 0 && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleClearAllCampaigns();
                  }}
                  className="text-[11px] font-semibold text-red-600 hover:text-red-700 hover:bg-red-50 px-2 py-1 rounded-lg bg-white border border-red-200 cursor-pointer flex items-center gap-1 transition-all"
                  title="Make campaigns count zero and start from scratch"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Reset All</span>
                </button>
              )}
            </div>
            <p className="text-xs text-slate-500 mb-4 font-light">
              Audit trails in progress or archived. High-density signals gather live local competitors and calculate GPM margins.
            </p>

            {/* Campaign Selection List */}
            <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
              {campaigns.length === 0 ? (
                <div className="bg-slate-50 border border-dashed border-slate-200 rounded-xl p-6 text-center text-xs text-slate-400 font-light">
                  No campaigns active. Touch the button above to launch your first worldwide vetting sprint.
                </div>
              ) : (
                campaigns.map((camp) => {
                  const isSelected = selectedCampaign?.id === camp.id;
                  const isProcessing = camp.status === "processing";
                  const leadsNum = camp.leads?.length || 0;

                  return (
                    <div
                      key={camp.id}
                      onClick={() => {
                        setSelectedCampaign(camp);
                        setSelectedLead(null); // Reset lead selection to view list first
                      }}
                      className={`relative cursor-pointer group p-4 rounded-xl border transition-all duration-200 ${
                        isSelected 
                          ? "bg-slate-50/50 border-[#EF6C00] shadow-xs ring-1 ring-[#EF6C00]/10" 
                          : "bg-white hover:bg-slate-50/50 border-slate-200"
                      }`}
                    >
                      <div className="flex justify-between items-start gap-2 mb-1.5">
                        <span className="font-serif text-sm font-bold text-slate-900 leading-tight block truncate pr-4">
                          {camp.name}
                        </span>
                        
                        <button
                          onClick={(e) => handleDeleteCampaign(camp.id, e)}
                          title="Delete Campaign"
                          className="text-slate-400 hover:text-red-600 hover:bg-slate-100 p-1 rounded-md transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2 mb-3">
                        <span className="bg-slate-50 text-slate-600 border border-slate-200/80 text-[10px] font-mono px-1.5 py-0.5 rounded flex items-center gap-1 font-semibold">
                          <Globe className="w-2.5 h-2.5 text-[#EF6C00]" />
                          {camp.country}
                        </span>

                        <span className="text-[10px] text-slate-400">
                          {new Date(camp.createdAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                        </span>
                      </div>

                      {/* Display Step Processing states & real-time bar */}
                      {isProcessing ? (
                        <div className="space-y-1.5">
                          <div className="flex justify-between items-center text-[10px] font-mono">
                            <span className="text-[#EF6C00] font-semibold animate-pulse flex items-center gap-1">
                              <Loader2 className="w-3 h-3 animate-spin" />
                              {camp.currentStep || "Querying Index..."}
                            </span>
                            <span className="text-xs text-slate-600">{camp.progress || 10}%</span>
                          </div>
                          
                          {/* Beautiful custom mini progress bar */}
                          <div className="w-full bg-slate-200 rounded-full h-1 overflow-hidden">
                            <div 
                              className="bg-[#EF6C00] h-full transition-all duration-300 rounded-full"
                              style={{ width: `${camp.progress || 10}%` }}
                            />
                          </div>

                          <div className="text-[9px] font-mono text-amber-700 bg-amber-50 rounded px-1.5 py-0.5 mt-2 text-center animate-pulse border border-amber-200">
                            🔄 RUNNING SCAN - CLICK TO VIEW LOG STREAM
                          </div>
                        </div>
                      ) : (
                        <div>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-slate-600 flex items-center gap-1 font-semibold">
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                              {leadsNum} Leads Vetted
                            </span>
                            
                            <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 group-hover:text-[#EF6C00] flex items-center transition-colors">
                              Manage Dossier
                              <ChevronRight className="w-3 h-3 ml-0.5" />
                            </span>
                          </div>

                          <div className="text-[9px] font-mono text-emerald-800 bg-emerald-50 rounded px-1.5 py-0.5 mt-2 text-center border border-emerald-100 font-semibold group-hover:bg-[#EF6C00]/10 group-hover:text-[#EF6C00] transition-colors">
                            ✅ COMPLETED - CLICK TILE TO EXPLORE DOSSIERS
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Value proposition reference panel (Architectural Vetting parameters info) */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
            <h3 className="font-serif text-sm font-semibold text-slate-800 mb-2 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#EF6C00]" />
              Vetting Rationale & GPM formula
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed mb-3 font-sans">
              Estimated GPM calculation leverages regional average labor overheads. In private cloud setups, HR service agencies face substantial margin degradation with high Workday/SAP user rates. 
            </p>
            <div className="bg-slate-50 border border-slate-200/80 rounded p-3 space-y-2 text-[11px] font-mono text-slate-600">
              <div className="flex justify-between">
                <span>APAC Professional:</span>
                <span className="text-right font-semibold">68% - 74% GPM</span>
              </div>
              <div className="flex justify-between">
                <span>EU Mittelstand:</span>
                <span className="text-right font-semibold">58% - 66% GPM</span>
              </div>
              <div className="flex justify-between">
                <span>US High-Overhead:</span>
                <span className="text-right font-semibold">50% - 55% GPM</span>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-200 flex items-center gap-2 text-xs text-[#EF6C00] font-medium font-sans">
              <span className="w-1.5 h-1.5 bg-[#EF6C00] rounded-full" />
              <span>Targeting: Complex SME customization</span>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: SEARCH RESULTS & DOSSIERS VIEW (8 Cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {selectedCampaign ? (
            <div>
              {/* Campaign Header banner */}
              <div className="bg-white border border-slate-200 rounded-xl p-6 mb-6 shadow-xs">
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs text-[#EF6C00] uppercase tracking-widest font-extrabold font-sans">
                        VETTING ACTIVE REGION
                      </span>
                      <span className="text-slate-350">•</span>
                      <span className="text-xs text-slate-500 font-sans">
                        {selectedCampaign.leads?.length || 0} candidates verified
                      </span>
                    </div>

                    <h2 className="font-serif text-2xl font-black tracking-tight text-slate-950 mb-2">
                      {selectedCampaign.name}
                    </h2>

                    <div className="flex flex-wrap items-center gap-2">
                      <span className="bg-[#EF6C00]/10 text-[#EF6C00] text-xs font-mono px-2 py-0.5 rounded-md font-semibold">
                        📍 {selectedCampaign.country}
                      </span>
                      <span className="bg-slate-50 text-slate-600 border border-slate-200/80 text-xs px-2 py-0.5 rounded-md font-mono">
                        Search Depth: {selectedCampaign.depth === "comprehensive" ? "Deep AI Crawl" : "Express scan"}
                      </span>
                      <span className="text-xs text-slate-400 font-light font-sans">
                        Analyzed {new Date(selectedCampaign.createdAt).toLocaleDateString()} at {new Date(selectedCampaign.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>

                  {/* Status Indicator */}
                  <div className="text-right self-start">
                    {selectedCampaign.status === "processing" ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-800 border border-amber-200 text-xs font-mono rounded-full font-bold">
                        <span className="w-1.5 h-1.5 bg-amber-600 rounded-full animate-ping" />
                        SCANNING REAL WORLD DATA
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-250 text-xs font-mono rounded-full font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        AI INGESTION COMPLETED
                      </span>
                    )}
                  </div>
                </div>

                {/* Real-time search terms used */}
                <div className="mt-4 pt-4 border-t border-slate-205">
                  <div className="text-xs text-slate-400 mb-2 font-mono uppercase tracking-wider font-semibold">
                    Target Lead Queries Executed:
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedCampaign.leadTypes?.map((lt, idx) => (
                      <span key={idx} className="bg-slate-50 border border-slate-200 text-[11px] text-slate-600 px-2.5 py-1 rounded-lg font-light">
                        "{lt.replace("[Country]", selectedCampaign.country).replace("[country]", selectedCampaign.country)}"
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Firm Size Distribution bento card */}
              {selectedCampaign.leads && selectedCampaign.leads.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6" id="firm-size-distribution-visualizer">
                  {/* SME Stats */}
                  <div 
                    onClick={() => setSelectedSegmentFilter(prev => prev === "SME" ? "All" : "SME")}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedSegmentFilter === "SME" 
                        ? "bg-[#EF6C00]/10 border-[#EF6C00] shadow-sm shadow-[#EF6C00]/5 ring-1 ring-[#EF6C00]" 
                        : "bg-white border-slate-200 hover:bg-slate-50/50 hover:border-[#EF6C00]/40"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-mono font-bold text-[#EF6C00] uppercase tracking-wider">Boutique SME Vendors</span>
                      <span className="text-[10px] font-mono font-semibold bg-[#EF6C00]/10 text-[#EF6C00] px-1.5 py-0.5 rounded-full">
                        {selectedCampaign.leads.filter(l => l.firmSizeSegment === "SME").length} Leads
                      </span>
                    </div>
                    <div className="text-2xl font-serif font-black text-slate-900">
                      {selectedCampaign.leads.length ? Math.round((selectedCampaign.leads.filter(l => l.firmSizeSegment === "SME").length / selectedCampaign.leads.length) * 100) : 0}%
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1 font-light leading-relaxed font-sans">
                      Agile local consultants, boutique CRM agencies. Highest potential service margin optimization (65%-75% GPM).
                    </p>
                    {/* Compact visualization bar */}
                    <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                      <div 
                        className="bg-[#EF6C00] h-full transition-all duration-300 pointer-events-none" 
                        style={{ width: `${selectedCampaign.leads.length ? (selectedCampaign.leads.filter(l => l.firmSizeSegment === "SME").length / selectedCampaign.leads.length) * 100 : 0}%` }}
                      />
                    </div>
                    <div className="text-[9px] font-mono text-slate-400 mt-2 text-right">
                      {selectedSegmentFilter === "SME" ? "★ Active Filter" : "Click to Filter List"}
                    </div>
                  </div>

                  {/* Mid-Market Stats */}
                  <div 
                    onClick={() => setSelectedSegmentFilter(prev => prev === "Mid-Market" ? "All" : "Mid-Market")}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedSegmentFilter === "Mid-Market" 
                        ? "bg-indigo-50 border-indigo-500 shadow-sm shadow-indigo-100 ring-1 ring-indigo-500" 
                        : "bg-white border-slate-200 hover:bg-slate-50/50 hover:border-indigo-500/40"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-mono font-bold text-indigo-700 uppercase tracking-wider">Mid-Market Integrators</span>
                      <span className="text-[10px] font-mono font-semibold bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded-full">
                        {selectedCampaign.leads.filter(l => l.firmSizeSegment === "Mid-Market").length} Leads
                      </span>
                    </div>
                    <div className="text-2xl font-serif font-black text-slate-900">
                      {selectedCampaign.leads.length ? Math.round((selectedCampaign.leads.filter(l => l.firmSizeSegment === "Mid-Market").length / selectedCampaign.leads.length) * 100) : 0}%
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1 font-light leading-relaxed font-sans">
                      Systems integrators, regional advisory firms. Balanced capacity to resell and pack compliance workflows (55%-62% GPM).
                    </p>
                    {/* Compact visualization bar */}
                    <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                      <div 
                        className="bg-indigo-600 h-full transition-all duration-300 pointer-events-none" 
                        style={{ width: `${selectedCampaign.leads.length ? (selectedCampaign.leads.filter(l => l.firmSizeSegment === "Mid-Market").length / selectedCampaign.leads.length) * 100 : 0}%` }}
                      />
                    </div>
                    <div className="text-[9px] font-mono text-slate-400 mt-2 text-right">
                      {selectedSegmentFilter === "Mid-Market" ? "★ Active Filter" : "Click to Filter List"}
                    </div>
                  </div>

                  {/* Enterprise Heavyweights Stats */}
                  <div 
                    onClick={() => setSelectedSegmentFilter(prev => prev === "Enterprise" ? "All" : "Enterprise")}
                    className={`p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedSegmentFilter === "Enterprise" 
                        ? "bg-purple-50 border-purple-500 shadow-sm shadow-purple-100 ring-1 ring-purple-500" 
                        : "bg-white border-slate-200 hover:bg-slate-50/50 hover:border-purple-500/40"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-mono font-bold text-purple-700 uppercase tracking-wider">Enterprise Titans</span>
                      <span className="text-[10px] font-mono font-semibold bg-purple-50 text-purple-700 px-1.5 py-0.5 rounded-full">
                        {selectedCampaign.leads.filter(l => l.firmSizeSegment === "Enterprise").length} Leads
                      </span>
                    </div>
                    <div className="text-2xl font-serif font-black text-slate-900">
                      {selectedCampaign.leads.length ? Math.round((selectedCampaign.leads.filter(l => l.firmSizeSegment === "Enterprise").length / selectedCampaign.leads.length) * 100) : 0}%
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1 font-light leading-relaxed font-sans">
                      Global systems integrators, top sovereign IT consultancies. Massive account networks with proprietary platforms (40%-50% GPM).
                    </p>
                    {/* Compact visualization bar */}
                    <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                      <div 
                        className="bg-purple-600 h-full transition-all duration-300 pointer-events-none" 
                        style={{ width: `${selectedCampaign.leads.length ? (selectedCampaign.leads.filter(l => l.firmSizeSegment === "Enterprise").length / selectedCampaign.leads.length) * 100 : 0}%` }}
                      />
                    </div>
                    <div className="text-[9px] font-mono text-slate-400 mt-2 text-right">
                      {selectedSegmentFilter === "Enterprise" ? "★ Active Filter" : "Click to Filter List"}
                    </div>
                  </div>
                </div>
              )}

              {/* Filtering & Sorting Panel inside Campaign */}
              {selectedCampaign.leads && selectedCampaign.leads.length > 0 && (
                <div className="bg-slate-100 border border-slate-200 rounded-xl p-4 mb-6 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex flex-wrap items-center gap-4">
                    
                    {/* Filter by Reputation */}
                    <div className="flex items-center gap-2">
                      <Filter className="w-3.5 h-3.5 text-[#EF6C00]" />
                      <label className="text-xs text-slate-600 font-semibold font-sans">Reputation:</label>
                      <select
                        value={selectedReputationFilter}
                        onChange={(e) => setSelectedReputationFilter(e.target.value)}
                        className="bg-white border border-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#EF6C00] font-sans font-medium text-slate-700 shadow-3xs cursor-pointer hover:border-slate-300 transition-colors"
                      >
                        <option value="All">All Statuses</option>
                        <option value="Institutional">Institutional</option>
                        <option value="Reputable">Reputable</option>
                        <option value="Rising">Rising</option>
                      </select>
                    </div>

                    {/* Filter by Firm Sizing */}
                    <div className="flex items-center gap-2">
                      <LayoutGrid className="w-3.5 h-3.5 text-[#EF6C00]" />
                      <label className="text-xs text-slate-600 font-semibold font-sans">Sizing:</label>
                      <select
                        value={selectedSegmentFilter}
                        onChange={(e) => setSelectedSegmentFilter(e.target.value)}
                        className="bg-white border border-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#EF6C00] font-sans font-medium text-slate-700 shadow-3xs cursor-pointer hover:border-slate-300 transition-colors"
                      >
                        <option value="All">All Sizes</option>
                        <option value="SME">Boutique SME (&lt; 150)</option>
                        <option value="Mid-Market">Mid-Market (150 - 1k)</option>
                        <option value="Enterprise">Enterprise (1k+)</option>
                      </select>
                    </div>

                    {/* Filter by Competitors */}
                    {competitorsInCampaign.length > 0 && (
                      <div className="flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-[#EF6C00]" />
                        <label className="text-xs text-slate-600 font-semibold font-sans">Competitor:</label>
                        <select
                          value={selectedCompetitorFilter}
                          onChange={(e) => setSelectedCompetitorFilter(e.target.value)}
                          className="bg-white border border-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#EF6C00] text-slate-700 shadow-3xs cursor-pointer hover:border-slate-300 transition-colors font-sans"
                        >
                          <option value="All">All Competitors</option>
                          {competitorsInCampaign.map((comp) => (
                            <option key={comp} value={comp}>{comp}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {/* Filter by Rival Neutrality */}
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <label className="text-xs text-slate-600 font-semibold font-sans">Rival Status:</label>
                      <select
                        value={selectedNeutralityFilter}
                        onChange={(e) => setSelectedNeutralityFilter(e.target.value)}
                        className="bg-white border border-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#EF6C00] font-sans text-slate-700 shadow-3xs cursor-pointer hover:border-slate-300 transition-colors"
                      >
                        <option value="All">All Partners</option>
                        <option value="RivalFree">Rival-Free Only</option>
                        <option value="Resellers">Competitor Resellers Only</option>
                      </select>
                    </div>

                  </div>

                  {/* Sort Controls */}
                  <div className="flex items-center gap-2 ml-auto">
                    <span className="text-xs text-slate-600 font-semibold font-sans">Sort By:</span>
                    <select
                      value={selectedLeadSort}
                      onChange={(e) => setSelectedLeadSort(e.target.value)}
                      className="bg-white border border-slate-200 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-[#EF6C00] text-slate-700 shadow-3xs cursor-pointer hover:border-slate-300 transition-colors font-sans"
                    >
                      <option value="default">Default Scan Rank</option>
                      <option value="partnerships-high">Partnerships Represented (High)</option>
                      <option value="revenue-estimate">Estimated Revenue (High)</option>
                      <option value="growth-potential">Calculated GPM (Optimal)</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Leads High Density Cards Grid */}
              {selectedCampaign.status === "processing" && selectedCampaign.leads.length === 0 ? (
                <div className="bg-white rounded-xl border border-dashed border-slate-200 p-12 text-center shadow-xs">
                  <div className="relative inline-block mb-4">
                    <Loader2 className="w-10 h-10 text-[#EF6C00] animate-spin" />
                    <Sparkles className="w-4 h-4 text-[#EF6C00] absolute -top-1 -right-1 animate-bounce" />
                  </div>
                  <h3 className="font-serif text-lg font-bold text-slate-900 mb-2">
                    Running Deep AI Vetting Scan...
                  </h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed font-light font-sans">
                    We are querying standard corporate registers, LinkedIn clusters, and local technology rosters. Our model is estimating regional labor margins, FY23/24 financials, and drafting custom partner target fits.
                  </p>
                  
                  {/* Visual simulated terminal logger code */}
                  <div className="mt-6 max-w-md mx-auto bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-left font-mono text-[10px] text-emerald-400 space-y-1 block shadow-inner">
                    <div className="text-slate-400">&gt; OrangeHRM Agent Node active: {serverStatus?.timestamp || "05:17:33Z"}</div>
                    <div>&gt; Invoking search grounding system targeting country: <span className="text-yellow-300">"{selectedCampaign.country}"</span></div>
                    {selectedCampaign.progress && selectedCampaign.progress > 20 && (
                      <div>&gt; Search Results Received. Commencing candidate profiling checks...</div>
                    )}
                    {selectedCampaign.progress && selectedCampaign.progress > 50 && (
                      <div className="text-[#EF6C00]">&gt; Google Gemini 3.5 evaluating competitive threat vectors...</div>
                    )}
                    <div className="text-neutral-500 animate-pulse">&gt; {selectedCampaign.currentStep || "Processing..."}</div>
                  </div>
                </div>
              ) : activeLeads.length === 0 ? (
                <div className="bg-white border border-slate-200 rounded-xl p-12 text-center text-xs text-slate-400 font-light font-sans shadow-2xs">
                  No vetted leads match the custom filters applied above. Try clearing selection metrics.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {activeLeads.map((lead) => {
                    const hasNotes = !!(lead as any).customNotes;
                    const reputationColors = 
                      lead.reputation?.status === "Institutional" ? "bg-purple-50 text-purple-800 border-purple-200" :
                      lead.reputation?.status === "Reputable" ? "bg-emerald-50 text-emerald-800 border-emerald-200" :
                      "bg-amber-50 text-amber-800 border-amber-200";

                    return (
                      <div
                        key={lead.id}
                        id={`lead-card-${lead.id}`}
                        onClick={() => handleLeadClick(lead)}
                        className="bg-white border border-slate-200 hover:border-[#EF6C00] hover:shadow-md hover:shadow-[#EF6C00]/5 rounded-xl p-5 cursor-pointer transition-all duration-300 relative group flex flex-col justify-between"
                      >
                        
                        <div>
                          {/* Card upper info row */}
                          <div className="flex justify-between items-start gap-2 mb-3">
                            <span className={`text-[9px] uppercase tracking-wider font-extrabold px-2 py-0.5 rounded border ${reputationColors}`}>
                              {lead.reputation?.status || "Vetted"}
                            </span>
                            <span className="text-xs font-mono text-slate-400">
                              {lead.employeeSize}
                            </span>
                          </div>

                          {/* Company Name */}
                          <h3 className="font-serif text-base font-bold text-slate-900 leading-snug mb-1 group-hover:text-[#EF6C00] transition-colors flex items-center gap-1">
                            {lead.name}
                            <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity text-[#EF6C00]" />
                          </h3>

                          {/* Location & Web info */}
                          <div className="flex items-center gap-2 text-xs text-slate-600 mb-3">
                            <span className="font-medium">📍 {lead.hqLocation}</span>
                            <span className="text-slate-300">•</span>
                            <span className="text-[11px] underline hover:text-[#EF6C00] truncate max-w-[120px] font-mono text-slate-400" title={lead.socialLinks?.website}>
                              {lead.socialLinks?.website?.replace("https://", "").replace("www.", "")}
                            </span>
                          </div>

                          {/* Enterprise Short Description */}
                          <p className="text-xs text-slate-500 leading-relaxed mb-4 line-clamp-2 font-light font-sans">
                            {lead.description}
                          </p>
                        </div>

                        {/* Fast Key-Value Dossier Metrics Foot */}
                        <div className="pt-4 border-t border-slate-100 space-y-3">
                          <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono">
                            <div className="bg-slate-50 p-1.5 rounded border border-slate-100">
                              <div className="text-slate-400 uppercase text-[8px] tracking-wider mb-0.5">Est. Revenue</div>
                              <div className="font-bold text-slate-800 text-[11px] truncate">{lead.financials?.revenue}</div>
                            </div>
                            <div className="bg-slate-50 p-1.5 rounded border border-slate-100">
                              <div className="text-slate-400 uppercase text-[8px] tracking-wider mb-0.5">Est. GPM</div>
                              <div className="font-bold text-[#EF6C00] text-[11px]">{lead.financials?.gpm}</div>
                            </div>
                            <div className="bg-slate-50 p-1.5 rounded border border-slate-100">
                              <div className="text-slate-400 uppercase text-[8px] tracking-wider mb-0.5 font-medium">Represents</div>
                              <div className="font-bold text-slate-800 text-[11px] truncate">
                                {lead.trackRecord?.competitors?.length || 0} rivals
                              </div>
                            </div>
                          </div>

                          {/* Competitors List Mini Tags */}
                          <div className="flex items-center gap-1.5 flex-wrap min-h-[22px]">
                            {lead.trackRecord?.competitors && lead.trackRecord.competitors.length > 0 ? (
                              <>
                                <span className="text-[9px] text-slate-400 font-mono lowercase">resells:</span>
                                {lead.trackRecord.competitors.slice(0, 3).map((comp, idx) => (
                                  <span key={idx} className="bg-slate-50 border border-slate-200 text-[9px] text-slate-600 px-1.5 py-0.2 rounded font-sans font-medium">
                                    {comp}
                                  </span>
                                ))}
                                {lead.trackRecord.competitors.length > 3 && (
                                  <span className="text-[9px] font-mono text-slate-400">+{lead.trackRecord.competitors.length - 3}</span>
                                )}
                              </>
                            ) : (
                              <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 text-[9px] px-1.5 py-0.5 rounded font-sans font-bold flex items-center gap-1 uppercase tracking-wider">
                                <ShieldCheck className="w-3 h-3 text-emerald-600 inline-block" />
                                Rival-Free (Independent)
                              </span>
                            )}
                          </div>

                          {/* Notes and Grounded Sources present tag indicators */}
                          <div className="flex justify-between items-center text-[10px] pt-1.5 border-t border-neutral-150 mt-2">
                            <span className="text-xs text-[#EF6C00] font-semibold tracking-wider font-serif inline-flex items-center gap-1">
                              Analysis Dossier
                              <ArrowRight className="w-3" />
                            </span>

                            <div className="flex items-center gap-1.5">
                              {lead.sources && lead.sources.length > 0 && (
                                <span className="inline-flex items-center gap-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-600 text-[9px] px-1.5 py-0.5 rounded font-mono font-semibold uppercase transition-colors" title={`Sourced from: ${lead.sources.map(s => s.title).join(', ')}`}>
                                  <Globe className="w-2.5 h-2.5 text-slate-500" />
                                  <span>{lead.sources.length} Sources</span>
                                </span>
                              )}
                              {hasNotes && (
                                <span className="inline-flex items-center gap-1 bg-[#EF6C00]/10 text-[#EF6C00] text-[9px] px-1.5 py-0.5 rounded font-mono font-bold uppercase">
                                  <FileText className="w-2.5 h-2.5" /> Notes
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Dedicated BDR Status & Proposal Draft Panel on the card */}
                          <div 
                            className="bg-slate-50/70 hover:bg-slate-50 p-3 rounded-lg border border-slate-200 mt-3.5 space-y-2.5 transition-all"
                            onClick={(e) => {
                              e.stopPropagation();
                            }}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider font-extrabold flex items-center gap-1 font-sans">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#EF6C00] animate-pulse" />
                                Outreach Milepost:
                              </span>
                              <select
                                value={(lead as any).outreachStatus || "not_contacted"}
                                onChange={(e) => handleCardOutreachStatusChange(lead.id, e.target.value)}
                                className="bg-white border border-slate-200 hover:border-[#EF6C00] text-[11px] px-2 py-1 rounded font-sans font-semibold text-slate-800 cursor-pointer focus:outline-none transition-colors shadow-3xs"
                              >
                                <option value="not_contacted">Uncontacted lead</option>
                                <option value="contact_made">Contact Made</option>
                                <option value="pitch_sent">Pitch Sent</option>
                                <option value="meeting_scheduled">Meeting Scheduled</option>
                                <option value="partnered">Partnered ✅</option>
                              </select>
                            </div>

                            <div className="space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-bold">Proposal Draft & CRM Notes:</span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    toggleCardNotesExpand(lead.id);
                                  }}
                                  className="text-[10px] text-[#EF6C00] hover:text-[#D45F00] hover:underline font-mono font-bold flex items-center gap-0.5"
                                >
                                  {expandedCardNotes[lead.id] ? "Minimize ▲" : "✏️ Edit Draft / Notes"}
                                </button>
                              </div>

                              {expandedCardNotes[lead.id] ? (
                                <div className="space-y-1.5 pt-1">
                                  <textarea
                                    value={cardNotesState[lead.id] !== undefined ? cardNotesState[lead.id] : ((lead as any).customNotes || "")}
                                    onChange={(e) => handleCardNotesChange(lead.id, e.target.value)}
                                    placeholder="Draft alliance message or log BDR responses here..."
                                    className="w-full h-24 text-xs p-2 bg-white border border-slate-300 rounded focus:ring-1 focus:ring-[#EF6C00] focus:border-[#EF6C00] outline-none font-sans leading-relaxed resize-none text-slate-900"
                                  />
                                  <div className="flex justify-between items-center text-[10px]">
                                    <span className="text-[9px] font-mono font-semibold text-emerald-700">
                                      {cardNotesStatus[lead.id] || "* Persists to Database"}
                                    </span>
                                    <button
                                      onClick={() => handleSaveCardNotes(lead.id)}
                                      className="bg-slate-900 text-white hover:bg-black font-semibold text-[10px] px-2.5 py-1 rounded transition-colors cursor-pointer"
                                    >
                                      Save Draft
                                    </button>
                                  </div>
                                </div>
                              ) : (
                                <p className="text-[11px] text-slate-600 line-clamp-1 italic font-light pl-1">
                                  {(lead as any).customNotes || "No custom proposal draft registered."}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>

                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center max-w-xl mx-auto flex flex-col items-center justify-center space-y-4 shadow-3xs">
              <div className="w-16 h-16 rounded-full bg-[#EF6C00]/10 flex items-center justify-center text-[#EF6C00]">
                <Building2 className="w-8 h-8" />
              </div>
              <div>
                <h3 className="font-serif text-xl font-bold text-slate-950 mb-2">
                  Partner Intel Workspace Empty
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto font-light font-sans">
                  Choose an existing vetting campaign on the left pane, or click <strong className="font-semibold text-[#EF6C00]">"New Country Scan"</strong> to launch a targeted worldwide agency auditing sprint.
                </p>
              </div>
              <button
                onClick={() => setIsFormOpen(true)}
                className="bg-[#EF6C00] text-white hover:bg-[#D45F00] px-4 py-2 rounded-lg text-xs font-semibold shadow-sm focus:outline-none transition-colors cursor-pointer"
              >
                Launch Discovery Engine
              </button>
            </div>
          )}

        </div>

      </main>
      )}

      {activeWorkspaceTab === "directory" && (
        <main className="flex-1 max-w-7xl w-full mx-auto p-6">
          <GlobalDirectory
            campaigns={campaigns}
            defaultCountry={filterCountry}
            onSelectLead={(lead, camp) => {
              setSelectedCampaign(camp);
              handleLeadClick(lead);
            }}
            onExportCSV={exportToCSV}
            onExportPDF={handleExportPDF}
          />
        </main>
      )}

      {activeWorkspaceTab === "grounding" && (
        <main className="flex-1 max-w-7xl w-full mx-auto p-6">
          <GroundingCenter campaigns={campaigns} />
        </main>
      )}

      {activeWorkspaceTab === "outreach" && (
        <main className="flex-1 max-w-7xl w-full mx-auto p-6">
          <OutreachTracker 
            campaigns={campaigns} 
            onUpdateOutreachStatus={handleUpdateOutreachStatus}
            onRefreshCampaigns={async () => { await fetchCampaigns(false); }}
          />
        </main>
      )}

      {activeWorkspaceTab === "countries" && (
        <main className="flex-1 max-w-7xl w-full mx-auto p-6 animate-in fade-in duration-300">
          <CountriesView
            campaigns={campaigns}
            onSelectCountry={(country) => {
              setFilterCountry(country);
              setActiveWorkspaceTab("directory");
            }}
          />
        </main>
      )}

      {activeWorkspaceTab === "analytics" && (
        <main className="flex-1 max-w-7xl w-full mx-auto p-6 animate-in fade-in duration-300">
          <AnalyticsView campaigns={campaigns} />
        </main>
      )}

      {/* DRAW-IN DOSSIER DETAIL PANEL (Slider overlay with beautiful Draw-In Animation) */}
      <div 
        className={`fixed inset-y-0 right-0 z-50 w-full max-w-2xl bg-[#F8FAFC] shadow-2xl border-l border-slate-200/80 transform transition-transform duration-300 ease-in-out flex flex-col select-none overflow-hidden ${
          selectedLead ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {selectedLead && (
          <div className="flex flex-col h-full select-text">
            
            {/* Drawer Header Toolbar */}
            <div className="p-6 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-10 shadow-3xs">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setSelectedLead(null)}
                  className="p-1 px-2.5 bg-white border border-slate-200 text-xs font-semibold rounded-lg text-slate-800 hover:bg-slate-50 hover:border-slate-350 cursor-pointer flex items-center gap-1 transition-colors"
                >
                  <X className="w-4 h-4 text-slate-700" />
                  <span>Close Detail</span>
                </button>
                <button
                  onClick={() => handleExportPDF(selectedLead, selectedCampaign?.name || "OrangeHRM_Campaign")}
                  className="p-1 px-2.5 bg-white border border-slate-205 text-xs font-semibold rounded-lg text-amber-800 hover:text-[#EF6C00] hover:border-[#EF6C00] hover:bg-amber-50/10 cursor-pointer flex items-center gap-1 transition-colors font-semibold"
                >
                  <FileText className="w-4 h-4 text-[#EF6C00]" />
                  <span>Export PDF Briefing</span>
                </button>
                <div className="h-4 w-px bg-slate-200" />
                <span className="text-xs text-slate-400 font-mono uppercase tracking-widest font-bold">
                  Dossier: {selectedLead.hqLocation}
                </span>
              </div>

              {/* Status tags */}
              <span className={`text-[10px] tracking-wider uppercase font-extrabold px-3 py-1 rounded-full border ${
                selectedLead.reputation?.status === "Institutional" ? "bg-purple-50 text-purple-800 border-purple-200" :
                selectedLead.reputation?.status === "Reputable" ? "bg-emerald-50 text-emerald-800 border-emerald-200" :
                "bg-amber-50 text-amber-800 border-amber-200"
              }`}>
                {selectedLead.reputation?.status || "Vetted Agent"}
              </span>
            </div>

            {/* Content Body */}
            <div className="flex-1 overflow-y-auto p-8 space-y-8 max-h-[calc(100vh-140px)] bg-slate-50/30">
              
              {/* Header Title block */}
              <div>
                <div className="flex items-center gap-2 mb-2 text-xs text-[#EF6C00] font-extrabold tracking-wider font-sans uppercase">
                  <Building2 className="w-4 h-4 text-[#EF6C00]" />
                  PARTNER AUDITING RECORD
                </div>
                
                <h2 className="font-serif text-3xl font-black text-slate-900 leading-tight mb-2">
                  {selectedLead.name}
                </h2>

                <p className="text-sm text-slate-500 leading-relaxed font-light font-sans">
                  {selectedLead.description}
                </p>
              </div>

              {/* Grid 1: Basic Firmographics */}
              <div className="border border-slate-200 rounded-xl p-5 bg-white grid grid-cols-2 gap-4 shadow-sm">
                <div>
                  <span className="text-[10px] text-slate-450 uppercase tracking-wider font-mono block mb-1 font-semibold">
                    Headquarters
                  </span>
                  <div className="text-sm font-semibold text-slate-800">
                    {selectedLead.hqLocation}
                  </div>
                </div>

                <div>
                  <span className="text-[10px] text-slate-450 uppercase tracking-wider font-mono block mb-1 font-semibold">
                    Employee Capacity
                  </span>
                  <div className="text-sm font-semibold text-slate-800">
                    {selectedLead.employeeSize}
                  </div>
                </div>

                <div className="col-span-2 pt-3 mt-3 border-t border-slate-100 flex items-center justify-between">
                  <div className="flex gap-4">
                    {selectedLead.socialLinks?.website && (
                      <a
                        href={selectedLead.socialLinks.website}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs text-[#EF6C00] hover:underline flex items-center gap-1 font-semibold font-sans"
                      >
                        <Globe className="w-3.5 h-3.5 text-[#EF6C00]" />
                        Official Website
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                    {selectedLead.socialLinks?.linkedin && (
                      <a
                        href={selectedLead.socialLinks.linkedin}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs text-slate-600 hover:underline flex items-center gap-1 font-sans"
                      >
                        <Briefcase className="w-3.5 h-3.5 text-slate-450" />
                        LinkedIn Company
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>

                  <span className="text-[10px] font-mono text-slate-400">
                    ID: {selectedLead.id.split("-")[2] || "Live"}
                  </span>
                </div>
              </div>

              {/* Segment 2: Estimated Financials Vetting */}
              <div className="space-y-3">
                <h3 className="font-serif text-sm font-bold text-slate-800 uppercase tracking-wider pb-1.5 border-b border-slate-200 flex items-center gap-2">
                  <Coins className="w-4 h-4 text-[#EF6C00]" />
                  Finances & Regional Margin Audit
                </h3>

                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-white border border-slate-200 rounded-xl p-3.5 text-center shadow-3xs">
                    <span className="text-[9px] uppercase tracking-wider font-mono text-slate-400 block mb-1 font-semibold">
                      EST. ANNUAL REVENUE
                    </span>
                    <strong className="text-base text-slate-800 block font-bold leading-tight">
                      {selectedLead.financials?.revenue}
                    </strong>
                    <span className="text-[9px] text-slate-400 block mt-1 font-sans">FY23/24 standard</span>
                  </div>

                  <div className="bg-white border border-slate-250 rounded-xl p-3.5 text-center shadow-3xs">
                    <span className="text-[9px] uppercase tracking-wider font-mono text-[#EF6C00] block mb-1 font-semibold">
                      ESTIMATED GPM
                    </span>
                    <strong className="text-base text-[#EF6C00] block font-black leading-tight">
                      {selectedLead.financials?.gpm}
                    </strong>
                    <span className="text-[9px] text-slate-400 block mt-1 font-sans">Regional margin cap</span>
                  </div>

                  <div className="bg-white border border-slate-200 rounded-xl p-3.5 text-center shadow-3xs">
                    <span className="text-[9px] uppercase tracking-wider font-mono text-slate-400 block mb-1 font-semibold">
                      FINANCIAL STATUS
                    </span>
                    <strong className="text-base text-slate-800 block font-bold leading-tight font-sans">
                      {selectedLead.financials?.status || "Private"}
                    </strong>
                    <span className="text-[9px] text-slate-400 block mt-1 font-sans">Asset valuation</span>
                  </div>
                </div>
              </div>

              {/* Segment 3: Partnerships Vetting & Competitors represented */}
              <div className="space-y-3">
                <h3 className="font-serif text-sm font-bold text-slate-800 uppercase tracking-wider pb-1.5 border-b border-slate-200 flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#EF6C00]" />
                  Track Record & Rival Ecosystems
                </h3>

                <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4 shadow-sm">
                  <div className="flex justify-between items-center text-xs font-sans">
                    <span className="text-slate-500 font-medium">Currently Represented Brands & Platforms:</span>
                    <span className="font-mono text-xs bg-slate-50 border border-slate-200 px-2 py-0.5 rounded-lg font-bold text-slate-700">
                      {selectedLead.trackRecord?.competitors && selectedLead.trackRecord.competitors.length > 0 
                        ? `${selectedLead.trackRecord.partnershipCount} Active integrations` 
                        : "No Rival Alliances"}
                    </span>
                  </div>

                  {selectedLead.trackRecord?.competitors && selectedLead.trackRecord.competitors.length > 0 ? (
                    <>
                      <div className="flex flex-wrap gap-2.5">
                        {selectedLead.trackRecord.competitors.map((comp, idx) => (
                          <span
                            key={idx}
                            className="bg-[#EF6C00]/10 border border-[#EF6C00]/20 text-[#EF6C00] text-xs font-semibold px-3 py-1 rounded-full flex items-center gap-1.5"
                          >
                            <span className="w-1.5 h-1.5 bg-[#EF6C00] rounded-full" />
                            {comp}
                          </span>
                        ))}
                      </div>

                      <div className="text-xs text-slate-400 italic font-light font-sans">
                        * This reseller faces aggressive pricing compression and restrictive SaaS margins represented by {selectedLead.trackRecord.competitors.join(", ")}.
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="bg-emerald-50/50 border border-emerald-200 rounded-xl p-4 text-emerald-950 text-xs flex items-start gap-2.5 font-sans">
                        <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold block text-emerald-900 mb-0.5">True Strategic Independence</span>
                          This consultancy has no binding loyalties representing rival software conglomerates. Perfect fit for launching premium, unconflicted system transformations.
                        </div>
                      </div>

                      <div className="text-xs text-emerald-700 font-light italic font-sans animate-pulse">
                        * Commencing partnership with OrangeHRM will secure a high-revenue, first-mover position in the target country's independent market segments.
                      </div>
                    </>
                  )}
                </div>
              </div>

              {/* Segment 4: Reputation Assessment Details */}
              <div className="space-y-3">
                <h3 className="font-serif text-sm font-bold text-slate-800 uppercase tracking-wider pb-1.5 border-b border-slate-200 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  Reputation & Market Sentiment Audit
                </h3>

                <div className="bg-white rounded-xl p-5 border border-slate-200 text-xs leading-relaxed text-slate-800 font-sans shadow-sm">
                  <div className="font-mono text-[9px] uppercase tracking-wider text-slate-400 mb-2 font-bold select-none">
                    Web Presence News Analytics logs
                  </div>
                  <p className="text-xs text-slate-500 leading-relaxed font-sans font-light">
                    {selectedLead.reputation?.details}
                  </p>
                </div>
              </div>

              {/* Segment 5: Pitch Strategy - THE WHY FOR ORANGEHRM */}
              <div className="bg-[#EF6C00]/5 border border-amber-200/40 rounded-xl p-6 relative overflow-hidden shadow-sm">
                <div className="absolute right-0 top-0 translate-x-3 -translate-y-3 w-28 h-28 bg-[#EF6C00]/5 rounded-full blur-xl pointer-events-none" />
                
                <h3 className="font-serif text-lg font-bold text-slate-900 mb-2 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#EF6C00]" />
                  Strategic Pitch: "Why OrangeHRM?"
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed font-light font-sans">
                  {selectedLead.strategicFit?.whyOrangeHRM}
                </p>

                <div className="mt-4 pt-4 border-t border-amber-200/50 grid grid-cols-2 gap-4 text-[11px] font-sans">
                  <div className="flex gap-2">
                    <Check className="w-4 h-4 text-[#EF6C00] shrink-0" />
                    <div>
                      <strong className="block text-slate-900 font-semibold">Modular Pricing Advantage</strong>
                      <span className="text-slate-500">Avoid flat 30% revenue locks from Workday.</span>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Check className="w-4 h-4 text-[#EF6C00] shrink-0" />
                    <div>
                      <strong className="block text-slate-900 font-semibold">Extensible open code</strong>
                      <span className="text-slate-500">Build customized country-specific plugins.</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Segment 6: VETTING NOTES LOGS (PERSISTED ON DATABASE) */}
              <div className="space-y-3 border-t border-slate-200 pt-6">
                <div className="flex justify-between items-center font-sans">
                  <h3 className="font-serif text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-slate-600" />
                    Internal Vetting Notes & CRM Log
                  </h3>
                  
                  {notesFeedback && (
                    <span className="text-[11px] font-semibold font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                      {notesFeedback}
                    </span>
                  )}
                </div>

                <div className="space-y-3">
                  <textarea
                    value={customVettingNotes}
                    onChange={(e) => setCustomVettingNotes(e.target.value)}
                    placeholder="E.g. Spoke to Director of Alliances on June 1st. They are frustrated with BambooHR lock-in and open to looking at the OrangeHRM module deck next Wednesday..."
                    className="w-full min-h-[100px] text-xs p-3 bg-white border border-slate-200 rounded-xl focus:ring-1 focus:ring-[#EF6C00]/50 focus:border-[#EF6C00] outline-none font-sans leading-relaxed resize-y placeholder:text-neutral-400"
                  />

                  <div className="flex justify-between items-center">
                    <span className="text-[10px] text-slate-400 font-mono">
                      * These remarks survive system cold-starts and persist securely with the audit files directory on database.
                    </span>

                    <button
                      onClick={handleSaveNotes}
                      disabled={isSavingNotes}
                      className="bg-slate-900 text-white hover:bg-black font-semibold text-xs px-4 py-2 rounded-lg flex items-center gap-2 select-none cursor-pointer focus:outline-none transition-colors"
                    >
                      {isSavingNotes ? (
                        <>
                          <Loader2 className="w-3 animate-spin text-white" />
                          <span>Syncing notes...</span>
                        </>
                      ) : (
                        <>
                          <Database className="w-3.5 h-3.5" />
                          <span>Sync Vetting Notes</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Grounding Web References (Google Index Citations) */}
              {selectedLead.sources && selectedLead.sources.length > 0 && (
                <div className="bg-[#FFF8F2] rounded-xl p-5 border border-[#FFD2B2] shadow-xs">
                  <div className="flex items-center gap-2 mb-3">
                    <Globe className="w-4 h-4 text-[#EF6C00]" />
                    <span className="text-xs uppercase tracking-wider font-mono text-[#EF6C00] font-extrabold">
                      🔍 Double-Verified Grounding Sources (Proof of Life)
                    </span>
                  </div>
                  <p className="text-xs text-[#514F4A] mb-3 leading-relaxed">
                    The following reference indexes were retrieved and authenticated by Gemini 3.5 in real-time to confirm the trade capacity and active corporate existence of <strong>{selectedLead.name}</strong>:
                  </p>

                  <div className="space-y-2">
                    {selectedLead.sources.slice(0, 3).map((src, i) => (
                      <a
                        key={i}
                        href={src.url}
                        target="_blank"
                        rel="noreferrer"
                        className="block bg-white hover:bg-[#FFF3E0] px-4 py-2.5 rounded-lg border border-[#FFC194] text-xs transition-all hover:translate-x-1 duration-150"
                      >
                        <div className="font-bold text-[#1A1A1B] flex items-center justify-between">
                          <span className="text-[#EF6C00] hover:underline flex items-center gap-1.5 font-sans">
                            <span className="text-[10px] bg-[#EF6C00]/10 text-[#EF6C00] px-1.5 py-0.2 rounded font-mono font-black">Ref #{i + 1}</span>
                            {src.title}
                          </span>
                          <ExternalLink className="w-3.5 h-3.5 text-[#EF6C00]" />
                        </div>
                        <div className="text-[11px] text-[#514F4A] truncate mt-1 font-mono">
                          {src.url}
                        </div>
                      </a>
                    ))}
                  </div>
                </div>
              )}

            </div>

          </div>
        )}
      </div>

      {/* POPUP MODAL: NEW COUNTRY DISCOVERY CAMPAIGN FORM */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            
            {/* Modal Title bar */}
            <div className="p-6 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#EF6C00]" />
                  Launch Advanced Country Scan
                </h3>
                <p className="text-xs text-slate-500 font-light font-sans">
                  Query real-time registries and ingest global targets directory.
                </p>
              </div>

              <button
                onClick={() => setIsFormOpen(false)}
                className="p-1 hover:bg-slate-200 transition-colors rounded-lg text-slate-500 block cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form content */}
            <form onSubmit={handleLaunchCampaign} className="p-6 space-y-5">

              {/* API Key warning / info */}
              {!clientApiKey && (
                <div className="text-[11px] text-amber-700 bg-amber-50 px-3 py-2.5 rounded-xl border border-amber-200/60 leading-normal flex items-start gap-2 font-sans select-none">
                  <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">No Gemini API key configured.</span> The tool will execute via simulated backend fallback. To retrieve real-time live channel intelligence, open Settings in the header and input a Gemini API Key.
                  </div>
                </div>
              )}
              
              {/* Campaign Custom label */}
              <div>
                <label className="text-xs uppercase tracking-wider font-mono text-slate-500 block mb-1 font-bold">
                  Campaign Label Name (Optional)
                </label>
                <input
                  type="text"
                  value={customCampaignName}
                  onChange={(e) => setCustomCampaignName(e.target.value)}
                  placeholder="e.g. Frankfurt Mid-market Alliance Vetting"
                  className="w-full text-xs p-3 bg-white border border-slate-200 rounded-xl outline-none focus:border-[#EF6C00] font-sans text-slate-900"
                />
              </div>

              {/* Batch Mode toggle */}
              <div className="flex items-center justify-between p-3 bg-[#FAF6F0] border border-[#EBE4D8] rounded-xl select-none">
                <div className="flex flex-col">
                  <span className="text-xs font-bold text-[#1A1A1B] font-sans">Batch Vetting Mode</span>
                  <span className="text-[9px] text-slate-400 font-light font-sans">Scout multiple countries sequentially in a single campaign run</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isBatchMode}
                    onChange={(e) => {
                      setIsBatchMode(e.target.checked);
                      if (!e.target.checked) {
                        setBatchCountries([]);
                      }
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#EF6C00]" />
                </label>
              </div>

              {/* Targeted Country Form Field */}
              <div className="space-y-3">
                {isBatchMode ? (
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-wider font-mono text-slate-500 block mb-1 font-bold">
                      Batch Target Countries
                    </label>
                    <CountrySelector
                      value=""
                      placeholder="Type country name and select to add to batch..."
                      onChange={(c) => {
                        if (c && !batchCountries.includes(c)) {
                          setBatchCountries(prev => [...prev, c]);
                        }
                      }}
                    />
                    {batchCountries.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5 p-2 bg-slate-50 border border-slate-200 rounded-xl max-h-32 overflow-y-auto">
                        {batchCountries.map((c) => (
                          <span
                            key={c}
                            className="inline-flex items-center gap-1 bg-[#EF6C00]/10 text-[#EF6C00] font-semibold text-[10px] px-2 py-0.5 rounded-lg border border-[#EF6C00]/25 select-none"
                          >
                            <span>{flag(c)} {c}</span>
                            <button
                              type="button"
                              onClick={() => setBatchCountries(prev => prev.filter(x => x !== c))}
                              className="text-[#EF6C00] hover:text-[#EF6C00]/80 focus:outline-none cursor-pointer font-bold text-xs"
                            >
                              ×
                            </button>
                          </span>
                        ))}
                      </div>
                    ) : (
                      <div className="text-[10px] text-slate-400 font-light font-sans p-3 border border-dashed border-slate-200 rounded-xl text-center bg-slate-50 select-none">
                        No countries added to batch list yet. Add at least one country to launch a batch scan.
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-2">
                    <label className="text-xs uppercase tracking-wider font-mono text-slate-500 block mb-1 font-bold">
                      Target Country
                    </label>
                    <CountrySelector
                      value={targetCountryOption === "custom" ? customCountryInput : targetCountryOption}
                      onChange={(val) => {
                        const verified = ["Germany", "United Kingdom", "United States", "Australia", "South Africa", "France", "India", "Canada"];
                        if (verified.includes(val)) {
                          setTargetCountryOption(val);
                          setCustomCountryInput("");
                        } else if (val) {
                          setTargetCountryOption("custom");
                          setCustomCountryInput(val);
                        } else {
                          setTargetCountryOption("");
                          setCustomCountryInput("");
                        }
                      }}
                      placeholder="Search or type country name..."
                    />

                    {targetCountryOption && targetCountryOption !== "custom" && (
                      <div className="text-[11px] text-emerald-700 bg-emerald-50 px-3 py-2 rounded-lg border border-emerald-200/50 flex items-center gap-1.5 font-sans leading-tight select-none">
                        <span className="text-emerald-500 font-bold">✨</span>
                        <span>This country uses our <strong>hand-vetted regional database</strong> as high-fidelity fallback. Safe from Google Serper rate limits!</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Presets Grid Multi Selection Checklist */}
              <div>
                <label className="text-xs uppercase tracking-wider font-mono text-slate-500 block mb-2 font-bold font-sans">
                  Vetting Target Profiles (Choose 1 or more)
                </label>
                
                <div className="space-y-2 max-h-[180px] overflow-y-auto border border-slate-200 rounded-xl p-3 bg-white">
                  {LEAD_TYPE_PRESETS.map((preset) => (
                    <div 
                      key={preset.id}
                      onClick={() => {
                        if (selectedPresets.includes(preset.id)) {
                          setSelectedPresets(prev => prev.filter(x => x !== preset.id));
                        } else {
                          setSelectedPresets(prev => [...prev, preset.id]);
                        }
                      }}
                      className="flex items-start gap-3 p-2 hover:bg-slate-50 rounded-lg cursor-pointer transition-colors"
                    >
                      <input
                        type="checkbox"
                        checked={selectedPresets.includes(preset.id)}
                        onChange={() => {}} // handled by div click
                        className="mt-1 accent-[#EF6C00] rounded focus:ring-0 focus:outline-none"
                      />
                      <div>
                        <div className="text-xs font-semibold text-slate-800 leading-tight">
                          {preset.label}
                        </div>
                        <div className="text-[10px] text-slate-400 font-light mt-0.5">
                          {preset.desc}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Vetting Search Depth Selector */}
              <div>
                <label className="text-xs uppercase tracking-wider font-mono text-slate-500 block mb-1 font-bold">
                  Scan Speed & Intensity Mode
                </label>
                <div className="grid grid-cols-2 gap-3 mt-1.5 font-sans">
                  <div
                    onClick={() => setSearchDepth("fast")}
                    className={`border rounded-xl p-3 cursor-pointer text-center transition-all ${
                      searchDepth === "fast" 
                        ? "border-[#EF6C00] bg-[#EF6C00]/5 font-semibold text-[#EF6C00]" 
                        : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50 animate-duration-100"
                    }`}
                  >
                    <div className="text-xs">Express Vetting</div>
                    <div className="text-[9px] text-slate-400 mt-0.5 font-light">Calculates matches swiftly</div>
                  </div>

                  <div
                    onClick={() => setSearchDepth("comprehensive")}
                    className={`border rounded-xl p-3 cursor-pointer text-center transition-all ${
                      searchDepth === "comprehensive" 
                        ? "border-[#EF6C00] bg-[#EF6C00]/5 font-semibold text-[#EF6C00]" 
                        : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
                    }`}
                  >
                    <div className="text-xs flex items-center justify-center gap-1.5">
                      <span>Comprehensive Scan</span>
                      <Sparkles className="w-3.5 h-3.5 text-[#EF6C00] animate-pulse" />
                    </div>
                    <div className="text-[9px] text-slate-400 mt-0.5 font-light">Deep search grounding analysis</div>
                  </div>
                </div>
              </div>

              {/* Form Footer Action pane */}
              <div className="border-t border-slate-150 pt-4 mt-6 flex items-center justify-between font-sans">
                <button
                  type="button"
                  onClick={() => {
                    setIsFormOpen(false);
                    setShowPasteFallback(true);
                  }}
                  className="text-[11px] text-[#EF6C00] hover:underline font-semibold cursor-pointer"
                >
                  Switch to Manual Paste Fallback
                </button>

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setIsFormOpen(false)}
                    className="bg-white border border-slate-200 text-xs font-semibold px-4 py-2.5 rounded-xl hover:bg-slate-50 hover:border-slate-300 transition-colors focus:outline-none cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={isSpawning || selectedPresets.length === 0 || (isBatchMode ? batchCountries.length === 0 : !(targetCountryOption === "custom" ? customCountryInput.trim() : targetCountryOption))}
                    className="bg-[#EF6C00] hover:bg-[#D45F00] text-white text-xs font-semibold px-5 py-2.5 rounded-xl shadow-md transition-colors focus:outline-none cursor-pointer flex items-center gap-2 disabled:bg-neutral-300 disabled:text-neutral-500 disabled:cursor-not-allowed"
                  >
                    {isSpawning ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin text-white" />
                        <span>Booting Vetting Node...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>Launch Ingestion Scan</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* POPUP MODAL: API KEYS & SETTINGS */}
      {isSettingsOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            
            <div className="p-6 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Settings className="w-5 h-5 text-[#EF6C00]" />
                  API Settings & Workspace Keys
                </h3>
                <p className="text-xs text-slate-500 font-light font-sans">
                  Configure your Google Gemini AI key and customize local parameters.
                </p>
              </div>
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="p-1 hover:bg-slate-200 transition-colors rounded-lg text-slate-500 block cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="text-xs uppercase tracking-wider font-mono text-slate-500 block mb-1 font-bold">
                  Gemini API Key (x-gemini-key)
                </label>
                <input
                  type="password"
                  value={clientApiKey}
                  onChange={(e) => setClientApiKey(e.target.value)}
                  placeholder="Enter your Gemini API key (or leave empty for simulated fallback)"
                  className="w-full text-xs p-3 bg-white border border-slate-200 rounded-xl outline-none focus:border-[#EF6C00] font-sans text-slate-900"
                />
                <p className="text-[10px] text-slate-400 mt-1 font-light leading-normal">
                  Your key is saved locally in your browser storage and passed directly via HTTP request headers to run live queries.
                </p>
              </div>

              <div>
                <label className="text-xs uppercase tracking-wider font-mono text-slate-500 block mb-1 font-bold">
                  Gemini AI Model (x-gemini-model)
                </label>
                <select
                  value={clientApiModel}
                  onChange={(e) => setClientApiModel(e.target.value)}
                  className="w-full text-xs p-3 bg-white border border-slate-200 rounded-xl outline-none focus:border-[#EF6C00] font-sans font-medium text-slate-800"
                >
                  <option value="gemini-2.0-flash">gemini-2.0-flash (Fast, accurate default)</option>
                  <option value="gemini-2.0-pro-exp-02-05">gemini-2.0-pro-exp (Deeper reasoning)</option>
                  <option value="gemini-1.5-pro">gemini-1.5-pro (Classic premium model)</option>
                  <option value="gemini-1.5-flash">gemini-1.5-flash (Legacy fast model)</option>
                </select>
              </div>

              <div className="border-t border-slate-100 pt-4 flex flex-col gap-2">
                <label className="text-xs uppercase tracking-wider font-mono text-slate-500 block font-bold">
                  Danger Zone
                </label>
                <button
                  type="button"
                  onClick={() => {
                    handleClearAllCampaigns();
                    setIsSettingsOpen(false);
                  }}
                  className="w-full bg-red-50 text-red-700 hover:bg-red-100 border border-red-200 text-xs font-semibold px-4 py-2.5 rounded-xl transition-colors focus:outline-none cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Clear All Workspace Lead Data</span>
                </button>
              </div>

              <div className="border-t border-slate-150 pt-4 mt-6 flex justify-end gap-3 font-sans">
                <button
                  type="button"
                  onClick={() => setIsSettingsOpen(false)}
                  className="bg-white border border-slate-200 text-xs font-semibold px-4 py-2.5 rounded-xl hover:bg-slate-50 hover:border-slate-300 transition-colors focus:outline-none cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => handleSaveSettings(clientApiKey, clientApiModel)}
                  className="bg-[#EF6C00] hover:bg-[#D45F00] text-white text-xs font-semibold px-5 py-2.5 rounded-xl shadow-md transition-colors focus:outline-none cursor-pointer"
                >
                  Save Settings
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* POPUP MODAL: BATCH SCOUTING PROGRESS OVERLAY */}
      {isBatching && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 select-none animate-in fade-in duration-200">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full shadow-2xl p-6 text-center space-y-5 animate-in fade-in zoom-in duration-200">
            <Loader2 className="w-10 h-10 mx-auto text-[#EF6C00] animate-spin" />
            
            <div className="space-y-1">
              <h3 className="font-serif text-lg font-bold text-slate-900">
                Batch Channel Vetting in Progress
              </h3>
              <p className="text-xs text-slate-500 font-light font-sans">
                Please wait while we query and ingest corporate rosters across designated sovereign markets.
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs font-mono font-bold text-slate-500 px-1">
                <span className="uppercase">Progress: {batchProgress}%</span>
                <span>
                  {batchActiveIndex + 1} / {batchCountries.length} Regions
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-3.5 border border-slate-200 overflow-hidden">
                <div
                  className="bg-[#EF6C00] h-full transition-all duration-300 rounded-full"
                  style={{ width: `${batchProgress}%` }}
                />
              </div>
            </div>

            {batchCountries[batchActiveIndex] && (
              <div className="bg-[#FAF6F0] border border-[#EBE4D8] rounded-xl p-3.5 flex items-center justify-center gap-3">
                <span className="text-3xl select-none" role="img" aria-label={batchCountries[batchActiveIndex]}>
                  {flag(batchCountries[batchActiveIndex])}
                </span>
                <div className="text-left">
                  <span className="text-[9px] uppercase tracking-wider font-mono text-slate-400 font-bold block">
                    CURRENTLY SCOUTING
                  </span>
                  <span className="font-serif text-sm font-bold text-slate-900 leading-tight block">
                    {batchCountries[batchActiveIndex]}
                  </span>
                </div>
              </div>
            )}

            <div className="text-[10px] font-mono text-[#EF6C00] uppercase font-bold animate-pulse">
              ● AI INGESTION ENGINE LIVE
            </div>
          </div>
        </div>
      )}

      {/* POPUP MODAL: MANUAL PASTE FALLBACK */}
      {showPasteFallback && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            
            <div className="p-6 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-[#EF6C00]" />
                  Manual Paste Fallback Scout
                </h3>
                <p className="text-xs text-slate-500 font-light font-sans">
                  No Gemini key? Generate a custom prompt, query any chatbot, and paste the JSON array back.
                </p>
              </div>
              <button
                onClick={() => setShowPasteFallback(false)}
                className="p-1 hover:bg-slate-200 transition-colors rounded-lg text-slate-500 block cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs uppercase tracking-wider font-mono text-slate-500 block mb-1.5 font-bold">
                    Target Country
                  </label>
                  <CountrySelector
                    value={manualScoutCountry}
                    onChange={setManualScoutCountry}
                    placeholder="Search or type country name..."
                  />
                </div>
                <div className="flex items-end">
                  <button
                    type="button"
                    disabled={!manualScoutCountry}
                    onClick={() => {
                      const resolvedFocus = LEAD_TYPE_PRESETS
                        .filter(p => selectedPresets.includes(p.id))
                        .map(p => p.label)
                        .join(", ");
                      const promptText = PROMPT_TEMPLATE(manualScoutCountry, resolvedFocus);
                      navigator.clipboard.writeText(promptText).then(() => {
                        alert("Prompt copied to clipboard! Paste it into Gemini, Claude, or ChatGPT.");
                      });
                    }}
                    className="w-full bg-[#EF6C00] hover:bg-[#D45F00] text-white text-xs font-semibold h-11 px-4 rounded-lg flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer disabled:bg-neutral-300 disabled:text-neutral-500 disabled:cursor-not-allowed"
                  >
                    <span>1. Copy AI Prompt</span>
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 text-xs font-semibold select-none">
                <a
                  href="https://aistudio.google.com"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                >
                  Google AI Studio ↗
                </a>
                <a
                  href="https://gemini.google.com"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                >
                  Gemini Chat ↗
                </a>
                <a
                  href="https://claude.ai"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                >
                  Claude.ai ↗
                </a>
                <a
                  href="https://chatgpt.com"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 hover:bg-slate-100 flex items-center gap-1"
                >
                  ChatGPT ↗
                </a>
              </div>

              <div className="space-y-1">
                <label className="text-xs uppercase tracking-wider font-mono text-slate-500 block mb-1 font-bold">
                  2. Paste JSON Response Array
                </label>
                <textarea
                  value={pasteInput}
                  onChange={(e) => setPasteInput(e.target.value)}
                  placeholder={`Paste the JSON array output here, e.g.\n[\n  { "company_name": "Example Ltd", "fit_score": 85, ... }\n]`}
                  className="w-full h-36 text-xs p-3 font-mono bg-white border border-slate-200 rounded-xl outline-none focus:border-[#EF6C00] text-slate-900"
                />
              </div>

              <div className="border-t border-slate-150 pt-4 flex justify-end gap-3 font-sans">
                <button
                  type="button"
                  onClick={() => setShowPasteFallback(false)}
                  className="bg-white border border-slate-200 text-xs font-semibold px-4 py-2.5 rounded-xl hover:bg-slate-50 hover:border-slate-300 transition-colors focus:outline-none cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={!pasteInput.trim() || !manualScoutCountry}
                  onClick={handleParsePaste}
                  className="bg-[#EF6C00] hover:bg-[#D45F00] text-white text-xs font-semibold px-5 py-2.5 rounded-xl shadow-md transition-colors focus:outline-none cursor-pointer disabled:bg-neutral-300 disabled:text-neutral-500 disabled:cursor-not-allowed"
                >
                  Parse & Import Leads
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer className="border-t border-[#EBE4D8] bg-[#FAF6F0] py-6 px-6 text-center text-xs text-[#827F78] mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 font-mono text-[10px]">
          <div>
            PRISTINE OATMEAL & INK ACCORDANCE • NO SAAS BLUE • VERIFIED STRATEGIC WORKSPACE
          </div>
          <div>
            © 2026 OrangeHRM Inc. Channel Recruitment Intelligence
          </div>
          <div className="flex gap-1 items-center">
            <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block" />
            <span>AI Studio Grounded Endpoint Online</span>
          </div>
        </div>
      </footer>

    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SocialLinks {
  linkedin?: string;
  x?: string;
  website?: string;
}

export interface Financials {
  revenue: string; // e.g. "$12.4M USD (FY23)"
  gpm: string; // e.g. "62%" (Estimated GPM based on regional service margins)
  status: "Listed" | "Private";
}

export interface TrackRecord {
  partnershipCount: number;
  competitors: string[]; // e.g. ["Workday", "BambooHR"]
}

export interface Reputation {
  status: "Reputable" | "Rising" | "Institutional";
  details: string; // e.g. "Over 15 years as a premier digital transformation boutique..."
}

export interface StrategicFit {
  whyOrangeHRM: string; // Tailored value proposition
}

export interface GroundingSource {
  title: string;
  url: string;
}

export interface PartnerLead {
  id: string;
  name: string;
  hqLocation: string;
  employeeSize: string;
  firmSizeSegment: "SME" | "Mid-Market" | "Enterprise";
  description: string;
  socialLinks: SocialLinks;
  financials: Financials;
  trackRecord: TrackRecord;
  reputation: Reputation;
  strategicFit: StrategicFit;
  sources: GroundingSource[];
  outreachStatus?: string;
  pitchEmail?: string;
  outreachNotes?: string;
  createdAt: string;
}

export interface Campaign {
  id: string;
  name: string;
  country: string;
  leadTypes: string[];
  depth: "fast" | "comprehensive";
  status: "pending" | "processing" | "completed" | "failed";
  currentStep?: string;
  progress?: number; // 0 to 100
  leads: PartnerLead[];
  createdAt: string;
}

export interface DiscoverRequest {
  country: string;
  leadTypes: string[];
  depth: "fast" | "comprehensive";
  campaignName?: string;
  targetSegments?: string[];
}
